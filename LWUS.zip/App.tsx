import React from 'react';

import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
} from 'react-native';
import Navigations from './src/presentation/navigation/Navigations';
import { Provider } from 'react-redux';
import { store } from './src/app/redux/store';

function App() {
 
  return (
    <Provider store={store}>
    <Navigations/>
    </Provider>
  );
}

const styles = StyleSheet.create({
 
});

export default App;
