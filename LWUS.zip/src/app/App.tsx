/*
 *  ELD Builder App
 *  SAK's Project
 *  Development By SAK (Sameer Abrar Khan)
 *  17-Feb-2023
 */

import React from "react";
import Navigations from "../presentation/navigation/Navigations";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/es/integration/react";
import Toast, { BaseToast } from "react-native-toast-message";
import Colors from "./utils/Colors";
import { persister, store } from "./redux/store";

const toastConfig = {
  /*
    Overwrite 'info' type,
    by modifying the existing `BaseToast` component
  */
  info: (props) => (
    <BaseToast
      {...props}
      text1NumberOfLines={4}
      style={{ borderLeftColor: Colors.green }}
      text1Style={{
        fontSize: 15,
        fontWeight: "400",
      }}
    />
  ),
  error: (props) => (
    <BaseToast
      {...props}
      text1NumberOfLines={4}
      style={{ backgroundColor: "tomato", borderLeftColor: "tomato" }}
      text1Style={{
        fontSize: 15,
        color: "#fff",
        fontWeight: "600",
      }}
    />
  ),
};

const App = () => {
  return (
    <Provider store={store}>
      <PersistGate persistor={persister}>
        <Navigations />
        <Toast config={toastConfig} />
      </PersistGate>
    </Provider>
  );
};

export default App;
