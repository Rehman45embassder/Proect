import { Dimensions, Platform } from "react-native";

export const PRODUCTION_URL = "";
export const STAGING_URL = "";
export const DEVELOPMENT_URL =
  "http://13.232.41.211/culturelingo/api/v1/";

export const BASEURL = DEVELOPMENT_URL;
export const WIDTH = Dimensions.get("window").width;
export const ScreenWIDTH = Dimensions.get("screen").width;
export const HEIGHT = Dimensions.get("window").height;
export const hitSlop = { top: 15, left: 15, bottom: 15, right: 15 };
export const GenericErrorMsg = "Something went wrong";
export const REMEMBER_TOKEN = "rememeber_me";
