import {Platform, ToastAndroid} from 'react-native';
import ToastNew from 'react-native-toast-message';

const NewToast = (msg: string) => {
  ToastNew.show({
    type: 'info',
    text1: msg,
    position: 'bottom',
    visibilityTime: 3000,
    bottomOffset: 60,
  });
};
export function toast(msg: string) {
  if (Platform.OS === 'android') {
    ToastAndroid.show(msg, ToastAndroid.SHORT);
    // msg && NewToast(msg);
  } else {
    msg && NewToast(msg);
  }
}
