import {Platform, ScrollView} from 'react-native';
import Colors from './Colors';
export default {
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingHorizontal: 10,
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  shadow: {
    backgroundColor: "#fff",
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.27,
    shadowRadius: 4.65,
    elevation: 6,
  },
  dropdownIndex: {
    ...Platform.select({
      ios: {
        zIndex: 999,
      },
    }),
  },
  bottomLine: {
    backgroundColor: '#fff',
    padding: 15,
    borderBottomWidth: 1,
    borderColor: '#00000029',
  },
};
