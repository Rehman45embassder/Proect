import {
  PERMISSIONS,
  request,
  check,
  RESULTS,
  checkMultiple,
  openSettings,
} from "react-native-permissions";
import { PermissionsAndroid, Platform, Alert } from "react-native";

import { toasito } from "./Extensions";

export async function isGalleryPermissionGranted() {
  try {
    const result = await check(
      Platform.select({
        android: PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE,
        ios: PERMISSIONS.IOS.PHOTO_LIBRARY,
      })
    );
    switch (result) {
      case RESULTS.UNAVAILABLE:
        toasito("This feature is not available on this device.");
        return;
      case RESULTS.DENIED:
        return (await requestGalleryPermission()) === "granted";
      case RESULTS.GRANTED:
        return true;
      case RESULTS.BLOCKED:
        toasito("The permission is denied and not requestable anymore");
        // SettingAlert({ type: 'location' });
        return false;
    }
  } catch (error) {
    console.log("Check permission error: ", error);
    return false;
  }
}
const requestGalleryPermission = async () => {
  const status = await request(
    Platform.select({
      android: PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE,
      ios: PERMISSIONS.IOS.PHOTO_LIBRARY,
    })
  );
  return status === "granted";
};

const requestMicrophonePermission = async () => {
  const status = await request(
    Platform.select({
      android: PERMISSIONS.ANDROID.RECORD_AUDIO,
      ios: PERMISSIONS.IOS.MICROPHONE,
    })
  );
  return status === "granted";
};
export const requestPermission = async () => {
  const status = await request(
    Platform.select({
      android: PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
      ios: PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
    })
  );
  return status;
};

const requestCameraPermission = async () => {
  const status = await request(
    Platform.select({
      android: PERMISSIONS.ANDROID.CAMERA,
      ios: PERMISSIONS.IOS.CAMERA,
    })
  );
  return status;
};
export const requestStoragePermission = async () => {
  const status = await request(PERMISSIONS.ANDROID.WRITE_EXTERNAL_STORAGE);
  return status;
};
export const checkAllPermissions = async () => {
  try {
    await PermissionsAndroid.requestMultiple([
      PermissionsAndroid.PERMISSIONS.CAMERA,
      PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
      PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
    ]);
    if (
      (await PermissionsAndroid.check("android.permission.CAMERA")) &&
      (await PermissionsAndroid.check(
        "android.permission.READ_EXTERNAL_STORAGE"
      )) &&
      (await PermissionsAndroid.check(
        "android.permission.WRITE_EXTERNAL_STORAGE"
      ))
    ) {
      console.log("You can use the camera");
      return true;
    } else {
      console.log("all permissions denied");
      return false;
    }
  } catch (err) {
    console.warn(err);
  }
};

export async function checkCameraPermission(setCameraDialog?: any) {
  let permissionGranted1 = false,
    permissionGranted2 = false;

  const SettingAlert = ({ type }: any) => {
    Alert.alert(
      "Seeible",
      `User did not grant ${type} permission. You Can Enable it in Settings`,
      [
        { text: "Cancel" },
        { text: "Open Settings", onPress: () => openSettings() },
      ]
    );
  };

  try {
    const status = await checkMultiple(
      Platform.select({
        android: [
          PERMISSIONS.ANDROID.CAMERA,
          PERMISSIONS.ANDROID.WRITE_EXTERNAL_STORAGE,
        ],
        ios: [PERMISSIONS.IOS.CAMERA],
      })
    );

    switch (status["android.permission.CAMERA"]) {
      case RESULTS.UNAVAILABLE:
        SettingAlert("Camera");
        console.log("This feature is not available on this device.");
        break;
      case RESULTS.DENIED:
        console.warn((await requestCameraPermission()) === "granted");
        if ((await requestCameraPermission()) === "granted") {
          permissionGranted1 = (await requestCameraPermission()) === "granted";
        } else {
          setCameraDialog && setCameraDialog(false);
          SettingAlert({ type: "Camera" });
        }
        break;
      case RESULTS.GRANTED:
        console.log("Camera permission is granted");
        permissionGranted1 = true;
        break;
      case RESULTS.BLOCKED:
        console.log("The permission is denied and not requestable anymore");
        SettingAlert({ type: "camera" });
        break;
    }
    switch (status["android.permission.WRITE_EXTERNAL_STORAGE"]) {
      case RESULTS.UNAVAILABLE:
        Alert.alert("This feature is not available on this device.");
        break;
      case RESULTS.DENIED:
        console.log("Storage permission is denied");
        permissionGranted2 = (await requestStoragePermission()) === "granted";
        break;
      case RESULTS.GRANTED:
        console.log("Storage permission is granted");
        permissionGranted2 = true;
        break;
      case RESULTS.BLOCKED:
        console.log("The permission is denied and not requestable anymore");
        SettingAlert({ type: "storage" });
        break;
    }
    return permissionGranted1 && permissionGranted2;
  } catch (error) {
    console.log("Check permission error: ", error);
  }
}
