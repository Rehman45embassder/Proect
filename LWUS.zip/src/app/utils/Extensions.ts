import {
  StyleSheet,
  KeyboardAvoidingView,
  View,
  Image,
  TextInput,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  Animated,
  Pressable,
  Alert,
  ImageBackground,
  ActivityIndicator,
  ToastAndroid,
  Platform,
} from "react-native";
import ToastNew from "react-native-toast-message";

export const AlertToast = (msg: string) => {
  ToastNew.show({
    type: "error",

    text1: msg,

    position: "bottom",

    visibilityTime: 2000,

    bottomOffset: 60,
  });
};

const NewToast = (msg: string) => {
  ToastNew.show({
    type: "info",
    text1: msg,
    position: "bottom",
    visibilityTime: 3000,
    bottomOffset: 60,
  });
};
export const toasito = (msg: string) => {
  if (Platform.OS == "android") {
    ToastAndroid.showWithGravityAndOffset(
      msg,
      ToastAndroid.LONG,
      ToastAndroid.BOTTOM,
      25,
      50
    );
  } else {
    NewToast(msg);
  }
};
