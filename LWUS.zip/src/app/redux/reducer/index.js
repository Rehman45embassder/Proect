import { combineReducers } from "redux";
import UseData from "../slice";
import { signupViewModelReducer } from "../../../presentation/modules/authentication/signup/SignUpViewModel";
export default combineReducers({
  UseData: UseData,
  signupViewModel: signupViewModelReducer,
});
