import {createSlice} from '@reduxjs/toolkit';
export const UseData = createSlice({
  name: 'UseData',
  initialState: {
    userRole: null,
    notifCount: [],
  },
  reducers: {
    fcmToken: (state, action) => {
      state.firebaseToken = action.payload;
    },
    saveMeHome: (state, action) => {
      state.Home = action.payload;
    },
    saveToken: (state, action) => {
      state.Token = action.payload;
    },
    profileData: (state, action) => {
      state.profileInfo = action.payload;
    },
    check: (state, action) => {
      state.condition = action.payload;
    },
    rememberMeAction: (state, action) => {
      state.email = action.payload.email;
      state.password = action.payload.password;
    },
    firstLogin: (state, action) => {
      state.onbording = action.payload;
    },
    allLanguages: (state, action) => {
      state.allLanguages = action.payload;
    },
  },
});

export const {
  fcmToken,
  profileData,
  saveMeHome,
  saveToken,
  check,
  rememberMeAction,
  firstLogin,
  allLanguages,
} = UseData.actions;
export default UseData.reducer;
