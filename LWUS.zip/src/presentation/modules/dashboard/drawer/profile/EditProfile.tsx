import React, { CSSProperties, useEffect, useLayoutEffect, useState } from "react";
import {
  Alert,
  Image,
  ImageBackground,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ViewStyle,
} from "react-native";
import MyView from "../../../../components/MyView";
import { StyledText } from "../../../../components/StyledText";
import Colors from "../../../../../app/utils/Colors";
import Images from "../../../../../app/utils/Images";
import StyledInput from "../../../../components/StylesInput";
import Fonts from "../../../../../app/utils/Fonts";
import StyledButton from "../../../../components/StyledButton";
import { goBack, navigate } from "../../../../navigation/NavigationService";
import Dialogs from "../../../../components/Dialogs";
// import { typePaymentM } from "../../drawer/settings/payment_method/PaymentMethod";
import { HEIGHT, WIDTH } from "../../../../../app/utils/AppConstants";
import { Spacer } from "../../../../components/Spacer";
import TitleBar from "../../../../components/TitleBar";
import ScanDialog from "../../../../components/ScanDialog";
import PhotoUploadDialog from "../../../../components/PhotoUploadDialog";
// import { ProfileUpdate } from "./EditProfileViewModel";

import ImagePicker from "react-native-image-crop-picker";
import {
  openSettings,
  PERMISSIONS,
  RESULTS,
  request,
} from "react-native-permissions";
import { AlertToast, toasito } from "../../../../../app/utils/Extensions";
import { checkCameraPermission } from "../../../../../app/utils/AppPermission";
import { useDispatch, useSelector } from "react-redux";
import { getAllLanguagesModel } from "../../../authentication/signup/SignUpViewModel";
import StyledDropDown from "../../../../components/StyledDropDown";
import { ProfileUpdate } from "./EditProfileViewModel";
import { useIsFocused } from "@react-navigation/native";
import { Dropdown } from "../../../../components/react-native-element-dropdown/src";

type Props = {
  route?: {
    params?: any;
  };
  style?: ViewStyle | CSSProperties;
  title?: string;
};
export const Title: React.FC<Props> = ({ title, style }: any) => (
  <Text style={[styles.text1, style]}>
    {title}
    <StyledText text=" *" style={styles.text2} />
  </Text>
);
export const Title2: React.FC<Props> = ({ title, style }: any) => (
  <Text style={[styles.text1, style]}>{title}</Text>
);

const EditProfile: React.FC<Props> = ({ route }) => {
  const prop = route?.params;
  const profileData = useSelector((state: any) => state?.UseData?.profileInfo);
  
  console.log("profile data", profileData);
  const [modal, setModal] = React.useState(false);
  const [modal2, setModal2] = React.useState(false);

  







  const [email, SetEmail] = React.useState(profileData?.email);
  const [age, SetAge] = React.useState(profileData?.age.toString());
  const [gender, SetGender] = React.useState(profileData?.gender);
  const [city, SetCity] = React.useState(profileData?.city);
  const [country, SetCountry] = React.useState(profileData?.country);
  const [language, SetLanguage] = React.useState(profileData?.language);
  const [profileName, setProfileName] = React.useState(profileData?.name);
  const [image, setImage] = React.useState(profileData?.pictureLink);
  const [loader, setLoader] = React.useState(false);
  var stateArr: {value: string; label: string}[] = [];
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(null);
  const [items, setItems] = useState([]);
  const [languages, setLanguages] = useState();

  const isFocused =useIsFocused()


  
  const stateListFunction = array => {
    console.log("inside funcation")
    array?.map((val: {id: string; name: string}) => {
      stateArr.push({
        value: val.id,
        label: val.name,
      });
    });
    return stateArr;
  };
  useEffect(() => {
    console.log("useEffect ran");
  }, []);
   useLayoutEffect(() => {
     
      getAllLanguagesModel({setLanguages: setLanguages}).then(() => {
        console.log("Languages:", languages);
        const stateData = stateListFunction(languages);
        console.log("statedata:", stateData);
        setItems(stateData); // Update items2 with state data
      });
    }, [isFocused]);


  console.log("Image", image);
  const SettingAlert = ({ type }: any) => {
    Alert.alert(
      "Seeible",
      `User did not grant ${type} permission. You Can Enable it in Settings`,
      [
        { text: "Cancel" },
        { text: "Open Settings", onPress: () => openSettings() },
      ]
    );
  };

  const uploadGallery = async () => {
    try {
      if (Platform.OS === "android") {
        const granted = await request(
          PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE
        );
        granted !== "granted" && SettingAlert({ type: "Gallery" });

        if (granted === "granted") {
          ImagePicker.openPicker({
            width: 300,
            height: 400,
            cropping: true,
            cropperCircleOverlay: true,
          }).then((image: { path: any }) => {
            setImage(image.path);
          });
        }
        setModal2(false);
      } else {
        const granted = await request(PERMISSIONS.IOS.PHOTO_LIBRARY_ADD_ONLY);
        if (granted) {
          const ref = await ImagePicker.openPicker({
            width: 300,
            height: 400,
            cropping: true,
            cropperCircleOverlay: true,
          });
          setImage(ref.path);
        }
        setModal2(false);
      }
    } catch (er: any) {
      setModal2(false);
      er.message === "User did not grant library permission."
        ? Alert.alert(
            "Seeible",
            er.message + " " + "You Can Enable it in Settings",
            [
              { text: "Cancel" },
              { text: "Open Settings", onPress: () => openSettings() },
            ]
          )
        : er.message != "User did not grant library permission." ||
          (er.message !== "User cancelled image selection" &&
            AlertToast(er.message));
    }
  };
  const useCamera = async () => {
    try {
      if (Platform.OS === "android") {
        const granted = await checkCameraPermission();
        if (granted) {
          ImagePicker.openCamera({
            width: 300,
            height: 400,
            cropping: true,
            cropperCircleOverlay: true,
          }).then((image) => {
            setImage(image.path);
          });
        }
        setModal2(false);
      } else {
        const res = await request(PERMISSIONS.IOS.CAMERA);
        res === "blocked" && SettingAlert({ type: "Camera" });
        const ref = await ImagePicker.openCamera({
          width: 300,
          height: 400,
          cropping: true,
          cropperCircleOverlay: true,
        });
        setImage(ref.path);
        setModal2(false);
        // SettingAlert({ type: "Camera" });
        // res === "blocked" && SettingAlert({ type: "Camera" });
      }
    } catch (er: any) {
      er.message === "User did not grant camera permission."
        ? Alert.alert(
            "BushelPro",
            er.message + " " + "You Can Enable it in Settings",
            [
              { text: "Cancel" },
              { text: "Open Settings", onPress: () => openSettings() },
            ]
          )
        : er.message !== "User cancelled image selection" ||
          (er.message !== "User did not grant camera permission." &&
            AlertToast(er.message));
      // setUploadOptDialog(!uploadOptDialog)
    }
  };
  const dispatch = useDispatch();
  return (
    <View style={styles.container}>
      <StatusBar hidden={true} />
      <View style={[styles.imageBgStyle]}>
        <ImageBackground
          style={[styles.imageBgStyle, { alignItems: "center", zIndex: 1 }]}
          source={Images.IcLoginBg}
        >
          <Spacer margin={"5%"} />
          <TitleBar title={"PROFILE"} onPressBack={() => goBack()} />
        </ImageBackground>
        <View style={[styles.modalView]}>
          <View
            style={{
              width: 200,
              height: 150,
              position: "absolute",

              justifyContent: "center",
              alignItems: "center",
              left: WIDTH / 5,
              bottom: HEIGHT / 1.5,
            }}
          >
            <ImageBackground
            imageStyle={styles.imageStyle}
               source={
              profileData?.pictureLink === null
                ? Images.IcContact
                : {
                    uri:`http://13.232.41.211/culturelingo/api/v1/files?fileName=${profileData?.pictureLink}`
                  }
            }
              style={styles.imageStyle}
            >
              <TouchableOpacity
                onPress={() => setModal2(!modal2)}
                style={{
                  justifyContent: "flex-end",
                  alignItems: "flex-end",
                  height: HEIGHT / 9,
                  width: WIDTH / 4.5,
                }}
              >
                <Image style={styles.icons} source={Images.IcImage} />
              </TouchableOpacity>
            </ImageBackground>
          </View>
          <Spacer margin={"8%"} />
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ marginTop: 25 }}
          >
            <View style={{ marginHorizontal: "2%", marginVertical: 25 }}>
              <StyledInput
                // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}     //   clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                // error={{status:true,message:"something went wrong"}}
                headerText="Email"
                value={email}
                edit={false}
                onChange={SetEmail}
                secureTextEntry={false}
                textStyle={{
                  color: Colors.black,
                  fontFamily: Fonts.Medium,
                  fontSize: Fonts.large_font,
                }}
                leftIcon={<Image style={styles.icons} source={Images.IcUser} />}
              />
               <Spacer margin={"2%"} />
              <StyledInput
                // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}     //   clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                // error={{status:true,message:"something went wrong"}}
                headerText="Name"
                placeholderText={email}
                value={profileName}
                onChange={setProfileName}
                edit={true}
                secureTextEntry={false}
                
                textStyle={{
                  color: Colors.black,
                  fontFamily: Fonts.Medium,
                  fontSize: Fonts.large_font,
                }}
                leftIcon={
                  <Image style={styles.icons} source={Images.IcEmail} />
                }
              />
              <Spacer margin={"2%"} />
              <StyledInput
                // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}     //   clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                // error={{status:true,message:"something went wrong"}}
                headerText="Age"
                secureTextEntry={false}
                onChange={SetAge}
                value={age}
                textStyle={{
                  color: Colors.black,
                  fontFamily: Fonts.Medium,
                  fontSize: Fonts.large_font,
                }}
                leftIcon={<Image style={styles.icons} source={Images.IcUser} />}
              />
              <Spacer margin={"2%"} />
              <StyledInput
                // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}     //   clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                // error={{status:true,message:"something went wrong"}}
                headerText="Gender"
                placeholderText={email}
                value={gender}
                onChange={SetGender}
                edit={true}
                secureTextEntry={false}
                
                textStyle={{
                  color: Colors.black,
                  fontFamily: Fonts.Medium,
                  fontSize: Fonts.large_font,
                }}
                leftIcon={
                  <Image style={styles.icons} source={Images.IcEmail} />
                }
              />
            
              <Spacer margin={"2%"} />
              <View
          style={{
            gap:12,
            zIndex: 999,
            // height: open ? 250 : null,
          }}
        >
               <StyledText text="Select Language" extraStyle={{
                        color: Colors.black,
                        fontFamily: Fonts.Medium,
                        fontSize: Fonts.large_font,
                      }}
           />
                    <Dropdown
          style={styles.dropdown}
          containerStyle={styles.shadow}
          data={stateListFunction(languages)}
          search
          searchPlaceholder="Search"
          selectedTextStyle={styles.selectedTextStyle}
          labelField="label"
          valueField="value"
          label="Dropdown"
          placeholder="Select Language"
          value={value}
          placeholderStyle={{
            color: '#C0C0C0',
            marginLeft: 20,
          }}
          // onFocus={() => setOpenModal(false)}
          onChange={item => {
            setValue(item.value);
            // setIsFocus2(false);
          }}/>

          </View>
          <Spacer margin={"2%"} />
              
              <StyledInput
                // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}     //   clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                // error={{status:true,message:"something went wrong"}}
                headerText="City"
                secureTextEntry={false}
                value={city}
                onChange={SetCity}
                textStyle={{
                  color: Colors.black,
                  fontFamily: Fonts.Medium,
                  fontSize: Fonts.large_font,
                }}
                leftIcon={
                  <Image style={styles.icons} source={Images.IcPhone} />
                }
              />
               <Spacer margin={"2%"} />
              <StyledInput
                // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}     //   clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                // error={{status:true,message:"something went wrong"}}
                headerText="Country"
                secureTextEntry={false}
                value={country}
                onChange={SetCountry}
                textStyle={{
                  color: Colors.black,
                  fontFamily: Fonts.Medium,
                  fontSize: Fonts.large_font,
                }}
                leftIcon={
                  <Image style={styles.icons} source={Images.IcPhone} />
                }
              />
              
              <Spacer margin={"5%"} />
              <View
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  marginBottom: 60,
                }}
              >
                <StyledButton
                  isLoading={loader}
                  title="SAVE"
                  onPress={() =>{if(value!=null||value!=undefined)
                    ProfileUpdate({
                      name: profileName,
                      email:email,
                      age:age,
                      gender:gender,
                      city:city,
                      languageId:value,
                      country:country,
                      image: image,
                      navigation: navigate,
                      dispatch: dispatch,
                      setLoader: setLoader,
                      setModal: setModal,
                      userId: profileData?.id,
                    });else{toasito("Language is required")}}
                  }
                  btnContStyle={{ marginTop: 15, width: WIDTH / 2 }}
                />
              </View>
            </View>
            <Dialogs
              visible={modal}
              onClose={() => setModal(!modal)}
              onBtn2Press={() => {
                setModal(!modal);
                navigate("My Profile", { title: "My Profile" });
              }}
              popup
              checkIcon
              title="PROFILE UPDATED!"
              btn2="Ok"
              description={"Your profile has been updated successfully."}
            />

            <PhotoUploadDialog
              visible={modal2}
              onClose={() => setModal2(!modal2)}
              onBtn1Press={() => {
                setModal2(!modal2);
                uploadGallery();
                //navigate("PaymentMethod", { title: "Payment Method" });
              }}
              onBtn2Press={() => {
                setModal2(!modal2);
                useCamera();
                //navigate("PaymentMethod", { title: "Payment Method" });
              }}
              onBtn3Press={() => {
                setModal2(!modal2);

                //navigate("PaymentMethod", { title: "Payment Method" });
              }}
              popup
              btn1="Gallery"
              btn2="Camera"
              btn3="Cancel"
            />
          </ScrollView>
        </View>
      </View>
    </View>
  );
};

export default EditProfile;

const styles = StyleSheet.create({
  icons: { width: 20, height: 20, resizeMode: "contain", marginRight: 10 },
  topTxt: {
    color: Colors.dividerColor,
    fontSize: 17,
    textAlign: "center",
    marginTop: 20,
  },
  text1: {
    fontFamily: Fonts.Medium,
    fontSize: 16,
    alignItems: "center",
    marginBottom: 3,
    color: Colors.black,
  },
  text2: {
    fontFamily: Fonts.Medium,
    fontSize: 16,
    color: Colors.red,
    textAlign: "center",
  },
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  imageBgStyle: { width: "100%", height: 360, alignItems: "center" },
  logoStyle: {
    top: 24,
    width: 144,
    height: 165,
  },
  loginFormStyle: {
    height: 22,
    backgroundColor: "red",

    paddingHorizontal: 20,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
    position: "absolute",
    bottom: 0,
  },
  modalView: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    height: HEIGHT / 1.3,
    width: WIDTH / 1.1,
    backgroundColor: "white",
    position: "absolute",
    top: 210,
    zIndex: 999,
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  container1: {
    width: WIDTH / 2,
    padding: 25,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  button1: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    backgroundColor: "#2AC062",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  closeButton: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FF3974",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 22,
  },
  image: {
    marginTop: 150,
    marginBottom: 10,
    width: "100%",
    height: 350,
  },
  text: {
    fontSize: 24,
    marginBottom: 30,
    padding: 40,
  },
  checkBoxContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginTop: 10,
  },
  innerCheckBox: { flexDirection: "row", alignItems: "center" },
  rememberMe: { color: Colors.black, fontFamily: Fonts.Medium },
  forgot: {
    color: Colors.black,
    textDecorationLine: "underline",
    fontFamily: Fonts.Medium,
  },
  signup1: {
    color: Colors.grey,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
  },
  signup2: {
    color: Colors.green,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
    fontFamily: Fonts.SemiBold,
  },
  bottomContainer: {
    marginTop: 80,
    flexDirection: "row",
    justifyContent: "center",
    paddingBottom: 20,
  },
  imgContainer: {
    marginTop: 25,
    marginBottom: HEIGHT / 30,
    alignItems: "center",
  },
  mainLogo: { width: 240, height: 80 },
  title: {
    fontSize: Fonts.xmedium_font,
    color: "#414042",
    alignSelf: "center",
    fontFamily: Fonts.Medium,
    textAlign: "center",
    width: 315,
  },
  imageStyle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    marginBottom: 12,
  }, dropdown: {
    height: 48,
    borderColor: 'gray',
    backgroundColor: 'white',
    borderWidth: 1,
    borderRadius: 5,
    // paddingHorizontal: 40,

    // marginTop: 20,
    // width: "100%",
  },
  selectedTextStyle: {
    color: 'black',
    marginLeft: 20,
  },
  shadow: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },}
});
