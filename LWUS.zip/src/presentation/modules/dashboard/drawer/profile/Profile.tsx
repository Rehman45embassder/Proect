import React, { CSSProperties, useEffect, useState } from "react";
import {
  BackHandler,
  Image,
  ImageBackground,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
  ViewStyle,
} from "react-native";
import MyView from "../../../../components/MyView";
import { StyledText } from "../../../../components/StyledText";
import Colors from "../../../../../app/utils/Colors";
import Images from "../../../../../app/utils/Images";
import StyledInput from "../../../../components/StylesInput";
import Fonts from "../../../../../app/utils/Fonts";
import StyledButton from "../../../../components/StyledButton";
import { goBack, navigate } from "../../../../navigation/NavigationService";
import Dialogs from "../../../../components/Dialogs";
// import { typePaymentM } from "../../drawer/settings/payment_method/PaymentMethod";
import { HEIGHT, WIDTH } from "../../../../../app/utils/AppConstants";
import { Spacer } from "../../../../components/Spacer";
import TitleBar from "../../../../components/TitleBar";
import { openDrawer } from "../../../../navigation/Navigations";
import { useIsFocused, useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import { getUserProfileModel } from "./EditProfileViewModel";
// import { userProfileData } from "./EditProfileViewModel";

type Props = {
  route?: {
    params?: any;
  };
  style?: ViewStyle | CSSProperties;
  title?: string;
};
export const Title: React.FC<Props> = ({ title, style }: any) => (
  <Text style={[styles.text1, style]}>
    {title}
    <StyledText text=" *" style={styles.text2} />
  </Text>
);
export const Title2: React.FC<Props> = ({ title, style }: any) => (
  <Text style={[styles.text1, style]}>{title}</Text>
);

const Profile: React.FC<Props> = (props) => {
  const profileData = useSelector((state: any) => state?.UseData?.profileInfo);
  console.log("profile data", profileData);
  const prop = props.route?.params;
  const [modal, setModal] = React.useState(false);
  const [modal2, setModal2] = React.useState(false);
  const [loader, setLoader] = React.useState(false);
  const [email, SetEmail] = React.useState("");
  const [age, SetAge] = React.useState("");
  const [gender, SetGender] = React.useState("");
  const [city, SetCity] = React.useState("");
  const [country, SetCountry] = React.useState("");
  const [language, SetLanguage] = React.useState("");
  const [profileName, setProfileName] = React.useState("");
  const [profileImage, setProfileImage] = React.useState();
  const isFocused = useIsFocused();
  const [counter, setCounter] = useState(0);
  const navigation = useNavigation();
  const dispatch = useDispatch();

  const currrentScreen = navigation?.getState()?.routeNames[0];
  console.log("current screen", currrentScreen);
  useEffect(() => {
    const backAction = () => {
      if (props.route?.params.title === "My Profile") navigate("Settings");
      else navigate(currrentScreen);

      return true;
    };

    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",

      backAction
    );

    return () => backHandler.remove();
  }, [isFocused]);

  useEffect(() => {
    if (currrentScreen == "Home Screen" && isFocused) {
      setProfileImage(profileData?.pictureLink);
      SetEmail(profileData?.email);
      SetCity(profileData?.city);
      SetCountry(profileData?.country);
      SetGender(profileData?.gender);
      SetAge(profileData?.age.toString());
      SetLanguage(profileData?.language);
      setProfileName(profileData?.name);
      getUserProfileModel({dispatch:dispatch})
    }
  }, [isFocused]);

  return (
    <View style={styles.container}>
      <StatusBar hidden={true} />
      <View style={[styles.imageBgStyle]}>
        <ImageBackground
          style={[styles.imageBgStyle, { alignItems: "center", zIndex: 1 }]}
          source={Images.IcLoginBg}
        >
          <Spacer margin={"5%"} />
          <TitleBar
            title={"PROFILE"}
            leftImagePath={Images.IcMenuWhite}
            onPressBack={() => openDrawer()}
          />
          
          <View style={[styles.modalView]}>
            <View
              style={{
                width: 200,
                height: 150,
                position: "absolute",
                justifyContent: "center",
                alignItems: "center",
                left: WIDTH / 5,
                bottom: HEIGHT / 1.55,
              }}
            >
              <Image
                source={
                  profileData?.pictureLink === null
                    ? Images.IcContact
                    : {
                        uri:`http://13.232.41.211/culturelingo/api/v1/files?fileName=${profileData?.pictureLink}`
                      }
                }
                style={styles.imageStyle}
              />

              <StyledText text={profileName} extraStyle={styles.title} />
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
            <Spacer margin={"12%"} />
              <View style={{ marginHorizontal: "1%", marginVertical: 5 }}>
                <StyledInput
                  // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}
                  // clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                  // error={{status:true,message:"something went wrong"}}
                  
                  
                  secureTextEntry={false}
                  edit={false}
                  value={email}
                  Height={77}
                  containerStyle={{
                    borderColor: "transparent",
                    height: HEIGHT / 10,
                    
                  }}
                  textStyle={{ color: Colors.silver }}
                  leftIcon={
                    <StyledText text="Email:" extraStyle={{color: Colors.black,fontSize:16}}/>
                  }
                />
                <StyledInput
                  // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}
                  // clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                  // error={{status:true,message:"something went wrong"}}
                  
                  containerStyle={{
                    borderColor: "transparent",
                    height: HEIGHT / 15,
                  }}
                  type={"numeric"}
                  edit={false}
                  value={age}
                  Height={77}
                  textStyle={{ color: Colors.silver }}
                  leftIcon={
                    <StyledText text="Age:" extraStyle={{color: Colors.black,fontSize:16,bottom:2}}/>
                  }
                />
                 <StyledInput
                  // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}
                  // clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                  // error={{status:true,message:"something went wrong"}}
                  
                  containerStyle={{
                    borderColor: "transparent",
                    height: HEIGHT / 15,
                  }}
                  
                  edit={false}
                  value={gender}
                  Height={77}
                  textStyle={{ color: Colors.silver }}
                  leftIcon={
                    <StyledText text="Gender:" extraStyle={{color: Colors.black,fontSize:16,bottom:2}}/>
                  }
                />
                 <StyledInput
                  // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}
                  // clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                  // error={{status:true,message:"something went wrong"}}

                  containerStyle={{
                    borderColor: "transparent",
                    height: HEIGHT / 15,
                  }}
                  
                  edit={false}
                  value={city}
                  Height={77}
                  textStyle={{ color: Colors.silver }}
                  leftIcon={
                    <StyledText text="City:" extraStyle={{color: Colors.black,fontSize:16,bottom:2}}/>
                  }
                />
                 <StyledInput
                  // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}
                  // clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                  // error={{status:true,message:"something went wrong"}}

                  containerStyle={{
                    borderColor: "transparent",
                    height: HEIGHT / 15,
                  }}
                  
                  edit={false}
                  value={country}
                  Height={77}
                  textStyle={{ color: Colors.silver }}
                  leftIcon={
                   <StyledText text="Country:" extraStyle={{color: Colors.black,fontSize:16,bottom:2}}/>
                  }
                />
                 <StyledInput
                  // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}
                  // clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                  // error={{status:true,message:"something went wrong"}}
                  
                  containerStyle={{
                    borderColor: "transparent",
                    height: HEIGHT / 15,
                  }}
                  
                  edit={false}
                  value={language}
                  Height={77}
                  textStyle={{ color: Colors.silver }}
                  leftIcon={
                    <StyledText text="Language:" extraStyle={{color: Colors.black,fontSize:16,bottom:2}}/>
                  }
                />
                
                <View
                  style={{ justifyContent: "center", alignItems: "center" }}
                >
                  <StyledButton
                    title="EDIT"
                    onPress={() =>
                      navigate("EditProfile", { title: "EDIT PROFILE" })
                    }
                    btnContStyle={{ marginTop: 15, width: WIDTH / 2 }}
                  />
                </View>
              </View>
              <Dialogs
                visible={modal}
                onClose={() => setModal(!modal)}
                onBtn2Press={() => {
                  setModal(!modal);
                  navigate("Home");
                }}
                popup
                checkIcon
                title="CONGRATULATIONS!"
                btn2="Ok"
                description={
                  "You have signed up for the 7 day free trial, cancel subscription free of charge before free trial ends."
                }
              />
              <Dialogs
                visible={modal2}
                onClose={() => setModal2(!modal2)}
                onBtn2Press={() => {
                  setModal2(!modal2);
                  navigate("PaymentMethod", { title: "Payment Method" });
                }}
                popup
                title="PAYMENT METHOD UPDATED"
                btn2="Ok"
                description={"Your card has been successfully updated."}
              />
            </ScrollView>
          </View>
        </ImageBackground>
      </View>
    </View>
  );
};

export default Profile;

const styles = StyleSheet.create({
  icons: {
    width: 20,
    height: 20,
    resizeMode: "contain",
    marginRight: 10,
  },
  topTxt: {
    color: Colors.dividerColor,
    fontSize: 17,
    textAlign: "center",
    marginTop: 20,
  },
  text1: {
    fontFamily: Fonts.Medium,
    fontSize: 16,
    alignItems: "center",
    marginBottom: 3,
    color: Colors.black,
  },
  text2: {
    fontFamily: Fonts.Medium,
    fontSize: 16,
    color: Colors.red,
    textAlign: "center",
  },
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  imageBgStyle: { width: "100%", height: 300 },
  logoStyle: {
    top: 24,
    width: 144,
    height: 165,
  },
  loginFormStyle: {
    height: 22,
    backgroundColor: "red",

    paddingHorizontal: 20,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
    position: "absolute",
    bottom: 0,
  },
  modalView: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    height: HEIGHT / 1.3,
    width: WIDTH / 1.1,
    backgroundColor: "white",
    position: "absolute",
    top: HEIGHT / 4.5,
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  container1: {
    width: WIDTH / 2,
    padding: 25,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  button1: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    backgroundColor: "#2AC062",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  closeButton: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FF3974",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 22,
  },
  image: {
    marginTop: 150,
    marginBottom: 10,
    width: "100%",
    height: 350,
  },
  text: {
    fontSize: 24,
    marginBottom: 30,
    padding: 40,
  },
  checkBoxContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginTop: 10,
  },
  innerCheckBox: { flexDirection: "row", alignItems: "center" },
  rememberMe: { color: Colors.black, fontFamily: Fonts.Medium },
  forgot: {
    color: Colors.black,
    textDecorationLine: "underline",
    fontFamily: Fonts.Medium,
  },
  signup1: {
    color: Colors.grey,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
  },
  signup2: {
    color: Colors.green,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
    fontFamily: Fonts.SemiBold,
  },
  bottomContainer: {
    marginTop: 80,
    flexDirection: "row",
    justifyContent: "center",
    paddingBottom: 20,
  },
  imgContainer: {
    marginTop: 25,
    marginBottom: HEIGHT / 30,
    alignItems: "center",
  },
  mainLogo: { width: 240, height: 80 },
  title: {
    fontSize: Fonts.xmedium_font + 1,
    color: "#414042",
    alignSelf: "center",
    fontFamily: Fonts.Medium,
    textAlign: "center",
    width: 315,
  },
  imageStyle: {
    width: 90,
    height: 90,
    marginBottom: 25,
    borderRadius: 45,
  },
});
