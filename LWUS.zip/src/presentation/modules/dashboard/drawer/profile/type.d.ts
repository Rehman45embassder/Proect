export interface UpdateProfile {
  name: string;
  setLoader?: Any;
  navigation?: any;
  dispatch?: any;
  phone?: string;
  image?: string;
}
