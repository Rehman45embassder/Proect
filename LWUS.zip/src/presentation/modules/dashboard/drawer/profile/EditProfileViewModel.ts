import { useSelector } from "react-redux";
import { profileData, saveToken } from "../../../../../app/redux/slice";
import { toasito } from "../../../../../app/utils/Extensions";
import ApiClient from "../../../../../data/networking/ApiClient";
import { navigateClear } from "../../../../navigation/NavigationService";
import { store } from "../../../../../app/redux/store";
import { Axios } from "axios";

export const getUserProfileModel = async (params:any) => {
  try {
    const res:any = await ApiClient.userData.profileData();
    console.log("get profile", res.data.data);
    
    if (res.data.status == 200 && res.data.status) {
      params.dispatch(profileData(res?.data?.data));
    } else {
      toasito(res?.data?.message ? res?.data?.message : res.message);
    }
  } catch (error:any) {
    if (error?.response?.data?.message == 'Unauthenticated.') {
      navigateClear("SignIn");
    }
    toasito(error?.response?.data?.message ? error?.response?.data?.message : error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
  }
};

// export const ProfileUpdate = async (params: any) => {
//   var obj = {
//     name: params.name,
//     phone: params.phone,
//     image: params.image,
//   };

//   const state = store.getState();
//   const token = state?.UseData?.Token;
//   console.log('====================================',token);
//   console.log(params);
//   console.log('====================================');
//   const bodyContent = new FormData();
//   if (params.image != null) {
//     const reUp = {
//       uri: params.image,
//       type: "image/jpeg",
//       name: `user_image.jpg${Math.random() * 100123123}.jpg`,
//     };

//     bodyContent.append("profilePicture", reUp);
//   }
//   bodyContent.append("name", params.name.toString());
//   bodyContent.append("email", params.email.toString());
//   bodyContent.append("languageId", params.languageId);
//   bodyContent.append("age", params.age);
//   bodyContent.append("gender", params.gender.toString());
//   bodyContent.append("city", params.city.toString());
//   bodyContent.append("country", params.country.toString());

//   try {
//     params.setLoader(true);
//     console.log("params in side model", bodyContent);
    
//       const headers = {
//         Accept: "application/json",
//         "Content-Type": "multipart/form-data",
//         Authorization: `Bearer ${token}`,
//       };
  
//       const response = await ApiClient.userData.profileUpdate( {id: params.userId }, bodyContent,headers);
    
//       console.log('====================================');
//       console.log(response.data.data);
//       console.log('====================================');
//       // if (response.data.status === true) {
//       //   params.setLoader(false);
//       //   console.log("Update Profile View model", response);
//       //   params.dispatch(profileData(response?.body?.data));
//       //   params.setModal(true);
//       // } else if (response.data.status === false) {
//       //   params.setLoader(false);
//       //   toasito(response.message);
//       // }
//     }  catch (error:any) {
//       params.setLoader(false);
//       console.log("inside profile user catch", error.message);
//       if (error?.response?.data?.message == 'Unauthenticated.') {
//         navigateClear("SignIn");
//       }
//       toasito(error?.response?.data?.message ? error?.response?.data?.message : error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
//     }
//   }



  export const ProfileUpdate = async (params: any) => {

  

      const state = store.getState();
  const token = state?.UseData?.Token;
    

  const formdata = new FormData();
  formdata.append("name", params.name);
  formdata.append("email", params.email);
  // formdata.append("password", params.password);
  formdata.append("age", params.age);
  formdata.append("gender",params.gender);
  formdata.append("city",params.city);
  formdata.append("country", params.country);
  formdata.append("languageId",params.languageId);
    // Check if image is provided and append it accordingly
      if (params.image != null) {
        formdata.append('profilePicture', {
          uri: params.image,
          type: 'image/jpeg',
          name: `user_image.jpg${Math.random() * 100123123}.jpg`,
        });
      }
  
      const myHeaders = new Headers();
myHeaders.append("Authorization", `Bearer ${token}`);
  
const requestOptions = {
  method: "PUT",
  headers: myHeaders,
  body: formdata,
  redirect: "follow"
};
  
  
     try {
        console.log("form body signUP",formdata);
        const response:any =await fetch(`http://13.232.41.211/culturelingo/api/v1/users/${params.userId}`, requestOptions)
        const res=await response.json();
        console.log('====================================');
        console.log("signUP",res);
        console.log('====================================');
        if(res.status == 200 && res.status){
  
          params.setModal(true);
          getUserProfileModel({dispatch:params.dispatch})
        }
          else{
            toasito(res?.data?.message?res?.data?.message:res.message)
        }
      } catch (error:any) {
        console.log("catch signUP1",error);
        console.log("catch signUP2",error.message);
        
        console.log("catch signUP4",error.data.errors);
        console.log("catch signUP5",error.data);
        if(error?.response?.data?.message=='Unauthenticated.'){
          navigateClear("SignIn");
        }
       toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
    }
  
  }

export const logOut = async (params: any) => {
 

  const state = store.getState();
  const token = state?.UseData?.Token;
    

  
      const myHeaders = new Headers();
myHeaders.append("Authorization", `Bearer ${token}`);
  
const requestOptions = {
  method: "POST",
  headers: myHeaders,
  redirect: "follow"
};
  
  
     try {
        const res:any =await fetch(`http://13.232.41.211/culturelingo/api/v1/auth/logout`, requestOptions)
        console.log("wihout jason",res);
        
        console.log('====================================');
        console.log("signUP",res.status);
        console.log('====================================');
        if(res.status == 200 && res.status){
  
          params.setModal(true);
          params.dispatch(saveToken(""));
          
          params.dispatch(profileData(""));
          ApiClient.clearTokenOnLogout()
          params.navigation("SignIn");
        }
          else{
            toasito(res?.data?.message?res?.data?.message:res.message)
        }
      } catch (error:any) {
        console.log("catch signUP1",error);
        console.log("catch signUP2",error.message);
        
        console.log("catch signUP4",error.data.errors);
        console.log("catch signUP5",error.data);
        if(error?.response?.data?.message=='Unauthenticated.'){
          navigateClear("SignIn");
        }
       toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
    }
  
};
