import { ActivityIndicator, Alert, SafeAreaView, ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";
import { Spacer } from "../../../components/Spacer";
import TitleBar from "../../../components/TitleBar";
import { openDrawer } from "../../../navigation/Navigations";
import Images from "../../../../app/utils/Images";
import Styles from "../../../../app/utils/Styles";
import { goBack, navigate } from "../../../navigation/NavigationService";
import { StyledText } from "../../../components/StyledText";
import Fonts from "../../../../app/utils/Fonts";
import { Image } from "react-native";
import { HEIGHT, WIDTH } from "../../../../app/utils/AppConstants";
import { useEffect, useState } from "react";
import StyledInput from "../../../components/StylesInput";
import Colors from "../../../../app/utils/Colors";
import StyledButton from "../../../components/StyledButton";
import { toasito } from "../../../../app/utils/Extensions";
import { getQuiz } from "./QuizViewModal";
import { useDispatch } from "react-redux";






const Quiz = () => {

const [data,setData] =useState()
const [word,setWord] = useState()
const [right,setRight] = useState()
const [loader,setLoader] = useState();
const dispatch=useDispatch()

useEffect(()=>{
  getQuiz({setData:setData,setLoader:setLoader,dispatch:dispatch});
},[])

console.log('====================================');
console.log("translation",data);
console.log('====================================');


    const CUSTOMER_STATUS = [
        {
          images: Images.teaching,
          
          type: 'Daily Phrases',
          cicleColor: '#FB9B9B',
          bgColor: '#FB9B9B33',
        },
        {
          images: Images.history,
          
          type: 'History',
          cicleColor: '#6FD2FE',
          bgColor: 'rgba(111, 210, 254,0.2)',
        },
        {
          images: Images.choose,
          
          type: 'Quiz',
          cicleColor: 'rgba(35, 134, 246, 0.8)',
          bgColor: 'rgba(35, 134, 246, 0.2)',
        },
        {
          images: Images.translator,
          type: 'Translation',
          cicleColor: '#FFD88D',
          bgColor: 'rgba(255, 216, 141, 0.3)',
        },
        {
            images: Images.choose,
            
            type: 'Quiz',
            cicleColor: 'rgba(35, 134, 246, 0.8)',
            bgColor: 'rgba(35, 134, 246, 0.2)',
          },
          {
            images: Images.translator,
            type: 'Translation',
            cicleColor: '#FFD88D',
            bgColor: 'rgba(255, 216, 141, 0.3)',
          },
      ];
    
      const CustomerStatus = ({word}) => {
        return (
          <TouchableOpacity
            activeOpacity={1}
            style={styles.status}
           >
              
            <View
              style={{
                backgroundColor: 'rgba(35, 134, 246, 0.2)',
                borderRadius: 10,
                // alignItems: 'center',
                justifyContent: 'center',
                paddingBottom: 10,
                height:HEIGHT/6
              }}>
            
            <View style={{marginTop: 10}}>
                <StyledText
                  style={styles.headingRegular}
                  text={`Word: ${word}`}
                  extraStyle={{
                    fontFamily: Fonts.SemiBold,
                    color: "#000",
                    fontSize: 17,
                  }}
                />
              </View> 

            
 
            </View>
          </TouchableOpacity>
        );
      };
    

      const CustomerStatus1 = ({word}) => {
        return (
          <TouchableOpacity
            activeOpacity={1}
            style={styles.status}
           >
              
            <View
              style={{
                backgroundColor: right? 'rgba(35, 255, 246, 0.2)':'rgba(255, 00, 00, 0.2)',
                borderRadius: 10,
                // alignItems: 'center',
                justifyContent: 'center',
                paddingBottom: 10,
                height:HEIGHT/6
              }}>
            
            <View style={{marginTop: 10}}>
                <StyledText
                  style={styles.headingRegular}
                  text={`Result: ${word}`}
                  extraStyle={{
                    fontFamily: Fonts.SemiBold,
                    color: "#000",
                    fontSize: 17,
                  }}
                />
              </View> 
              {!right?
              <View style={{marginTop: 10}}>
                <StyledText
                  style={styles.headingRegular}
                  text={`Answer is: ${data?.answers[0]?.answer}`}
                  extraStyle={{
                    fontFamily: Fonts.SemiBold,
                    color: "#000",
                    fontSize: 17,
                  }}
                />
              </View> : null}

            
 
            </View>
          </TouchableOpacity>
        );
      };
    




    return (
      <SafeAreaView style={{flex:1}}>
         <Spacer margin={"4%"} />
      <TitleBar
        onPressBack={() => goBack()}
        leftImagePath={Images.IcGreenArrowBack}
        
        textColor
        title="QUESTION"
      />
       <Spacer margin={"4%"}/>

     
       <View style={{padding:WIDTH/25}}>


       <CustomerStatus word={data?.question}/>

             <StyledInput
                      containerStyle={{ height: HEIGHT / 15 }}
                      headerText="Enter Your Answer"
                      placeholderText="Enter Answer here"
                      secureTextEntry={false}
                      value={word}
                      onChange={setWord}
                      // error={{status:true,message:"something went wrong"}}
                      textStyle={{
                        color: Colors.black,
                        fontFamily: Fonts.Medium,
                        fontSize: Fonts.large_font,
                      }}
                     
                    />
                    <Spacer margin={"4%"} />
     {right==true?
          <CustomerStatus1 word={"Excellent"}/> :right==false? <CustomerStatus1 word={"Try Again"}/> : null
         }
<Spacer margin={"5%"} />
              <View
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  marginBottom: 60,
                }}
              >
                <StyledButton
                  
                  title="Submit"
                  onPress={() =>{if(word!=null||word!=undefined){
                    if (word?.toLowerCase() === data?.answers[0]?.answer.toLowerCase()) {
                        // Strings are equal ignoring case sensitivity
                        // Handle your logic here for matching strings
                        // For example:
                        setRight(true)
                        setTimeout(() => {
                            goBack()
                          }, 3000);
                      } else {
                        // Strings are not equal ignoring case sensitivity
                        // Handle your logic here for non-matching strings
                        // For example:
                        setRight(false)
                        console.log("Words do not match!");
                      }

                    setWord("")
                  }
                    else{toasito("Word is required")}}
                  }
                  btnContStyle={{ marginTop: 15, width: WIDTH / 2 }}
                />
              </View>
   
   </View>
      </SafeAreaView>
    );
  };
  
  export default Quiz;
  
  const styles = StyleSheet.create({ status: {
    width: WIDTH/1.1,
    height:HEIGHT/6,
    borderRadius: 10,
    ...Styles.shadow,
    marginVertical: 15,
    marginRight: 10,
    
  }});
  