import { SafeAreaView, ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";
import { StyledText } from "../../components/StyledText";
import { Spacer } from "../../components/Spacer";
import TitleBar from "../../components/TitleBar";
import { openDrawer } from "../../navigation/Navigations";
import Images from "../../../app/utils/Images";
import { navigate } from "../../navigation/NavigationService";
import Colors from "../../../app/utils/Colors";
import { Image } from "react-native";
import Fonts from "../../../app/utils/Fonts";
import Styles from "../../../app/utils/Styles";
import { FlatList } from "react-native";
import { HEIGHT } from "../../../app/utils/AppConstants";

const Dashboard = () => {

  const CUSTOMER_STATUS = [
    {
      images: Images.teaching,
      
      type: 'Daily Phrases',
      cicleColor: '#FB9B9B',
      bgColor: '#FB9B9B33',
    },
    {
      images: Images.history,
      
      type: 'History',
      cicleColor: '#6FD2FE',
      bgColor: 'rgba(111, 210, 254,0.2)',
    },
    {
      images: Images.choose,
      
      type: 'Question',
      cicleColor: 'rgba(35, 134, 246, 0.8)',
      bgColor: 'rgba(35, 134, 246, 0.2)',
    },
    {
      images: Images.translator,
      type: 'Translation',
      cicleColor: '#FFD88D',
      bgColor: 'rgba(255, 216, 141, 0.3)',
    },
  ];

  const CustomerStatus = ({item}) => {
    return (
      <TouchableOpacity
        activeOpacity={1}
        style={styles.status}
        onPress={() => {
          if(item.type === 'Daily Phrases'){
            navigate("Daily")
          }
          else  if(item.type === 'Translation'){
            navigate("Translation")
          } 
          else  if(item.type === 'History'){
            navigate("History")
          } else  if(item.type === 'Question'){
            navigate("Quiz")
          } 
        }}>
          
        <View
          style={{
            backgroundColor: item.bgColor,
            borderRadius: 10,
            alignItems: 'center',
            justifyContent: 'center',
            paddingBottom: 10,
          }}>
          <View
            style={{
              height: 100,
              ...Styles.center,
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}>
            <View
              style={{
                width: 70,
                height: 70,
                borderRadius: 50,
                backgroundColor: item.cicleColor,
                ...Styles.center,
              }}>
              <Image
                source={item.images}
                style={{
                  width: 40,
                  height: 40,
                }}
                resizeMode="contain"
              />
            </View>
          </View>
        
          <View style={{marginTop: 10}}>
            <StyledText
              style={styles.headingRegular}
              text={item.type}
              extraStyle={{
                fontFamily: Fonts.Medium,
                color: "#000",
                fontSize: 15,
              }}
            />
          </View>
        </View>
      </TouchableOpacity>
    );
  };



    return (
      <SafeAreaView>
         <Spacer margin={"4%"} />
      <TitleBar
        onPressBack={() => openDrawer()}
        leftImagePath={Images.IcMenu}
                onPressRightImage={() => navigate("Notification")}
        textColor
        title="DASHBOARD"
      />
      <Spacer margin={"8%"}/>
        <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          flexDirection: 'row',
          flexWrap: 'wrap',
          paddingLeft: 14,
          height: HEIGHT / 1.2,
          flexGrow: 1,
        }}>
        {CUSTOMER_STATUS.map(item => (
          <CustomerStatus item={item} />
        ))}
      </ScrollView>
      </SafeAreaView>
    );
  };
  
  export default Dashboard;
  
  const styles = StyleSheet.create({ status: {
    width: 120,
    borderRadius: 10,
    ...Styles.shadow,
    flexGrow: 1,
    marginVertical: 15,
    marginRight: 15,
  }});
  