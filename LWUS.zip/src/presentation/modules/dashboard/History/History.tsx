import { ActivityIndicator, Alert, SafeAreaView, ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";
import { Spacer } from "../../../components/Spacer";
import TitleBar from "../../../components/TitleBar";
import { openDrawer } from "../../../navigation/Navigations";
import Images from "../../../../app/utils/Images";
import Styles from "../../../../app/utils/Styles";
import { goBack, navigate } from "../../../navigation/NavigationService";
import { StyledText } from "../../../components/StyledText";
import Fonts from "../../../../app/utils/Fonts";
import { Image } from "react-native";
import { HEIGHT, WIDTH } from "../../../../app/utils/AppConstants";
import { useEffect, useState } from "react";
import StyledInput from "../../../components/StylesInput";
import Colors from "../../../../app/utils/Colors";
import StyledButton from "../../../components/StyledButton";
import { toasito } from "../../../../app/utils/Extensions";
import { getHistory } from "./HistoryViewModel";





const History = () => {

const [data,setData] =useState()
const [word,setWord] = useState("It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident,")
const [loader,setLoader] = useState(false);

useEffect(()=>{
  getHistory({setData:setData,setLoader:setLoader});
},[])

console.log('====================================');
console.log("translation",data?.paragraphs);
console.log('====================================');


    const CUSTOMER_STATUS = [
        {
          images: Images.teaching,
          
          type: 'Daily Phrases',
          cicleColor: '#FB9B9B',
          bgColor: '#FB9B9B33',
        },
        {
          images: Images.history,
          
          type: 'History',
          cicleColor: '#6FD2FE',
          bgColor: 'rgba(111, 210, 254,0.2)',
        },
        {
          images: Images.choose,
          
          type: 'Quiz',
          cicleColor: 'rgba(35, 134, 246, 0.8)',
          bgColor: 'rgba(35, 134, 246, 0.2)',
        },
        {
          images: Images.translator,
          type: 'Translation',
          cicleColor: '#FFD88D',
          bgColor: 'rgba(255, 216, 141, 0.3)',
        },
        {
            images: Images.choose,
            
            type: 'Quiz',
            cicleColor: 'rgba(35, 134, 246, 0.8)',
            bgColor: 'rgba(35, 134, 246, 0.2)',
          },
          {
            images: Images.translator,
            type: 'Translation',
            cicleColor: '#FFD88D',
            bgColor: 'rgba(255, 216, 141, 0.3)',
          },
      ];
    
    




    return (
      <SafeAreaView style={{flex:1}}>
         <Spacer margin={"4%"} />
      <TitleBar
        onPressBack={() => goBack()}
        leftImagePath={Images.IcGreenArrowBack}
        
        textColor
        title="HISTORY"
      />
       <Spacer margin={"4%"}/>
       <ScrollView style={{padding:WIDTH/25,}}>
       <StyledText
           style={styles.headingRegular}
           text={data?.title}
           extraStyle={{
             fontFamily: Fonts.SemiBold,
             color: "#000",
             fontSize: 17,
           }}
         />
         <Spacer margin={"1%"}/>
        <View>
       <Image
                source={
                  {
                        uri:`http://13.232.41.211/culturelingo/api/v1/files?fileName=${data?.pictureLink}`
                      }
                }
                style={{ width: "100%", height: 360, }}
              />
              </View>
                    <Spacer margin={"3%"} />

                    {data?.paragraphs?.map(item => (
          <View style={{marginTop: 10,marginBottom: 25}}>
          <StyledText
            style={styles.headingRegular}
            text={item.text}
            extraStyle={{
              fontFamily: Fonts.SemiBold,
              color: "#000",
              fontSize: 15,
            }}
          />
         
        </View>  
        ))}
        {/* {loader===false?
         <View style={{marginTop: 10,marginBottom: 25}}>
         <StyledText
           style={styles.headingRegular}
           text={word}
           extraStyle={{
             fontFamily: Fonts.SemiBold,
             color: "#000",
             fontSize: 17,
           }}
         />
         <Spacer margin={"4%"}/>
       </View>  
          :
          <ActivityIndicator color={"#000"} size={"large"}/> 
        } */}

</ScrollView>
              
      </SafeAreaView>
    );
  };
  
  export default History;
  
  const styles = StyleSheet.create({ status: {
    width: WIDTH/1.1,
    height:HEIGHT/6,
    borderRadius: 10,
    ...Styles.shadow,
    marginVertical: 15,
    marginRight: 10,
    
  }});
  