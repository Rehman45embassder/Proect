import { store } from "../../../../app/redux/store";
import { toasito } from "../../../../app/utils/Extensions";
import { navigateClear } from "../../../navigation/NavigationService";

export const getDailyPhrase = async (params: any) => {
 

    const state = store.getState();
    const token = state?.UseData?.Token;
      
  
    
        const myHeaders = new Headers();
  myHeaders.append("Authorization", `Bearer ${token}`);
    
  const requestOptions = {
    method: "GET",
    headers: myHeaders,
    redirect: "follow"
  };
    
    params.setLoader(true)
       try {
          const response :any =await fetch(`http://13.232.41.211/culturelingo/api/v1/phrases`, requestOptions)
          const res = await response.json();
          console.log("wihout jason",res);
          
          console.log('====================================');
          console.log("signUP",res.status);
          console.log('====================================');
          if(res.status == 200 && res.status){
            params.setLoader(false)
           params.setData(res?.data)
          }
            else{
                params.setLoader(false)
              toasito(res?.data?.message?res?.data?.message:res.message)
          }
        } catch (error:any) {
            params.setLoader(false)
          console.log("catch signUP1",error);
          console.log("catch signUP2",error.message);
          
          console.log("catch signUP4",error.data.errors);
          console.log("catch signUP5",error.data);
          if(error?.response?.data?.message=='Unauthenticated.'){
            navigateClear("SignIn");
          }
         toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
      }
    
  };
  