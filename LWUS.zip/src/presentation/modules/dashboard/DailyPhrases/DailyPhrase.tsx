import { Alert, SafeAreaView, ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";
import { Spacer } from "../../../components/Spacer";
import TitleBar from "../../../components/TitleBar";
import { openDrawer } from "../../../navigation/Navigations";
import Images from "../../../../app/utils/Images";
import Styles from "../../../../app/utils/Styles";
import { goBack, navigate } from "../../../navigation/NavigationService";
import { StyledText } from "../../../components/StyledText";
import Fonts from "../../../../app/utils/Fonts";
import { Image } from "react-native";
import { HEIGHT, WIDTH } from "../../../../app/utils/AppConstants";
import { useEffect, useState } from "react";
import { getDailyPhrase } from "./DailyPhraseViewModel";




const DailyPhrase = () => {

const [data,setData] =useState()
const [loader,setLoader] = useState();

useEffect(()=>{
  getDailyPhrase({setData:setData,setLoader:setLoader});
},[])

console.log('====================================');
console.log("phrase",data);
console.log('====================================');


    const CUSTOMER_STATUS = [
        {
          images: Images.teaching,
          
          type: 'Daily Phrases',
          cicleColor: '#FB9B9B',
          bgColor: '#FB9B9B33',
        },
        {
          images: Images.history,
          
          type: 'History',
          cicleColor: '#6FD2FE',
          bgColor: 'rgba(111, 210, 254,0.2)',
        },
        {
          images: Images.choose,
          
          type: 'Quiz',
          cicleColor: 'rgba(35, 134, 246, 0.8)',
          bgColor: 'rgba(35, 134, 246, 0.2)',
        },
        {
          images: Images.translator,
          type: 'Translation',
          cicleColor: '#FFD88D',
          bgColor: 'rgba(255, 216, 141, 0.3)',
        },
        {
            images: Images.choose,
            
            type: 'Quiz',
            cicleColor: 'rgba(35, 134, 246, 0.8)',
            bgColor: 'rgba(35, 134, 246, 0.2)',
          },
          {
            images: Images.translator,
            type: 'Translation',
            cicleColor: '#FFD88D',
            bgColor: 'rgba(255, 216, 141, 0.3)',
          },
      ];
    
      const CustomerStatus = ({item}) => {
        return (
          <TouchableOpacity
            activeOpacity={1}
            style={styles.status}
           >
              
            <View
              style={{
                backgroundColor: '#FB9B9B33',
                borderRadius: 10,
                // alignItems: 'center',
                justifyContent: 'center',
                paddingBottom: 10,
                height:HEIGHT/6
              }}>
            
            <View style={{marginTop: 10}}>
                <StyledText
                  style={styles.headingRegular}
                  text={"English Text:"}
                  extraStyle={{
                    fontFamily: Fonts.SemiBold,
                    color: "#000",
                    fontSize: 17,
                  }}
                />
              </View> 

 <View style={{marginTop: 10}}>
                <StyledText
                  style={styles.headingRegular}
                  text={`  ${item?.englishText}`}
                  extraStyle={{
                    fontFamily: Fonts.Medium,
                    color: "#000",
                    fontSize: 15,
                  }}
                />
              </View> 
            
              <View style={{marginTop: 10}}>
                <StyledText
                  style={styles.headingRegular}
                  text={"Meaning:"}
                  extraStyle={{
                    fontFamily: Fonts.SemiBold,
                    color: "#000",
                    fontSize: 17,
                  }}
                />
              </View>
              <View style={{marginTop: 10}}>
                <StyledText
                  style={styles.headingRegular}
                  text={`  ${item?.originalText}`}
                  extraStyle={{
                    fontFamily: Fonts.Medium,
                    color: "#000",
                    fontSize: 15,
                  }}
                />
              </View> 
 
            </View>
          </TouchableOpacity>
        );
      };
    




    return (
      <SafeAreaView style={{flex:1}}>
         <Spacer margin={"4%"} />
      <TitleBar
        onPressBack={() => goBack()}
        leftImagePath={Images.IcGreenArrowBack}
        
        textColor
        title="DAILY PHRASES"
      />
       <Spacer margin={"4%"}/>
        <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
       justifyContent:"center",
       alignItems:"center",
       paddingLeft:14,
       
       
        }}>
        {data?.map(item => (
          <CustomerStatus item={item} />
        ))}
      </ScrollView>

      </SafeAreaView>
    );
  };
  
  export default DailyPhrase;
  
  const styles = StyleSheet.create({ status: {
    width: WIDTH/1.1,
    height:HEIGHT/6,
    borderRadius: 10,
    ...Styles.shadow,
    marginVertical: 15,
    marginRight: 10,
    
  }});
  