import React, { useState, useEffect } from "react";
import { View, Image, StyleSheet, Animated, Easing } from "react-native";
import Images from "../../../app/utils/Images";
import { navigate, navigationRef } from "../../navigation/NavigationService";
import { CommonActions } from "@react-navigation/native";
import { useSelector } from "react-redux";
import ApiClient from "../../../data/networking/ApiClient";

const SplashScreen = () => {
  const [showLogo, setShowLogo] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [loginHeight, setLoginHeight] = useState(0);
  const [fadeAnim] = useState(new Animated.Value(0));
  const [overlayOpacity] = useState(new Animated.Value(0.8));
  const [logoPosition] = useState(new Animated.Value(0));
  const [logoSize] = useState(new Animated.Value(1));
  const redirectHome = useSelector((state: any) => state.UseData.Home);
  const profileInfo = useSelector((state: any) => state?.UseData?.Token);
  console.log("redirectHome====", redirectHome);
  console.log("token====", profileInfo);
  // useEffect(() => {
  //   Animated.timing(fadeAnim, {
  //     toValue: 1,
  //     duration: 1500,
  //     easing: Easing.linear,
  //     useNativeDriver: true,
  //   }).start();
  // }, [fadeAnim]);

  // useEffect(() => {
  //   setTimeout(() => {
  //     setShowLogo(true);
  //   }, 500);
  // }, []);

  // useEffect(() => {
  //   if (showLogo) {
  //     Animated.timing(overlayOpacity, {
  //       toValue: 0,
  //       duration: 800,
  //       easing: Easing.linear,
  //       useNativeDriver: true,
  //     }).start();
  //   }
  // }, [showLogo]);

  // React.useEffect(() => {
  //   setTimeout(() => {
  //     navigate("SignIn");
  //   }, 3000);
  // }, []);

  // useEffect(() => {
  //   if (showLogin) {
  //     Animated.parallel([
  //       Animated.timing(logoPosition, {
  //         toValue: -250,
  //         duration: 500,
  //         easing: Easing.easeOutCubic,
  //         useNativeDriver: false,
  //       }),
  //       Animated.timing(logoSize, {
  //         toValue: 0.7,
  //         duration: 600,
  //         easing: Easing.easeOutCubic,
  //         useNativeDriver: false,
  //       }),
  //     ]).start(() => {
  //       // if (redirectHome) {
  //       //   ApiClient.setAuthHeader(profileInfo);
  //       //   navigate("Home");
  //       // } else {
  //       navigate("SignIn");
  //       //}
  //     });
  //   }
  // }, [showLogin]);

  React.useEffect(() => {
    setTimeout(() => {
      navigate("SignIn");
    }, 1500);
  }, []);

  return (
    <View style={styles.container}>
      <Image
        source={Images.IcLoginBg}
        style={styles.backgroundImage}
        resizeMode="cover"
      />

    
        <View
          style={[
            styles.container1,
            {
              // top: logoPosition,
              //transform: [{ scale: logoSize }],
            },
          ]}
        >
          <Image
            source={Images.IcSplash}
            style={[styles.logo]}
          />
        </View>
   
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: null,
    height: null,
  },
  logoContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
  },
  logoImage: {
    width: 200,
    height: 200,
  },
  container1: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    width: 244,
    height: 280,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "white",
  },
});

export default SplashScreen;

// import React from 'react';
// import {Image, ImageBackground, StyleSheet, View} from 'react-native';
// import Images from '../../../app/utils/Images';

// type Props = {
//   navigation?: any;
// };
// const SplashScreen: React.FC<Props> = props => {
//   return (
//     <View style={{flex: 1}}>
//       <ImageBackground
//         resizeMode="cover"
//         style={{width: '100%', height: '100%'}}
//         source={Images.bgSplash}>
//         <View
//           style={{
//             width: '100%',
//             height: '100%',
//             justifyContent: 'center',
//             alignItems: 'center',
//           }}>
//           <Image style={styles.logoStyle} source={Images.IcSplash} />
//         </View>
//       </ImageBackground>
//     </View>
//   );
// };
// const styles = StyleSheet.create({
//   logoStyle: {width: 190, height: 220},
// });
// export default SplashScreen;
