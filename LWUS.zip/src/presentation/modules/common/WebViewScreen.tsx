import React, { useRef, useEffect } from "react";
import { WebView } from "react-native-webview";
import {
  ActivityIndicator,
  SafeAreaView,
  View,
  StyleSheet,
} from "react-native";
import { HEIGHT, WIDTH } from "../../../app/utils/AppConstants";
import Colors from "../../../app/utils/Colors";

type Props = {
  route: any;
};

const Webview: React.FC<Props> = ({ route }) => {
  const LoadingIndicatorView = () => {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: Colors.white,
          justifyContent: "center",
        }}
      >
        <ActivityIndicator
          color={Colors.mehron}
          size="large"
          style={{
            width: 100,
            height: 100,
            marginBottom: "20%",
            alignSelf: "center",
            backgroundColor: Colors.white,
          }}
        />
      </View>
    );
  };

  return (
    <View style={styles.mainContainer}>
      <WebView
        source={{
          uri: route.params.url,
        }}
        renderLoading={LoadingIndicatorView}
        startInLoadingState={true}
      />
    </View>
  );
};
export default Webview;

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: Colors.lighterGreen,
  },
});
