// import { LoginRequest } from "./type";
// import { loginRepo } from "../../../../domain/repository/Repository";
// import { Alert } from "react-native";
// import { AlertToast, toasito } from "../../../../app/utils/Extensions";

import { saveMeHome, saveToken } from "../../../../app/redux/slice";
import { toasito } from "../../../../app/utils/Extensions";
import ApiClient from "../../../../data/networking/ApiClient";
import { getUserProfileModel } from "../../dashboard/drawer/profile/EditProfileViewModel";

// import {
//   profileData,
//   saveMeHome,
//   saveToken,
//   setProfileData,
// } from "../../../../app/redux/slice";
// import ApiClient from "../../../../data/networking/ApiClient";

// export const signin = async (params: LoginRequest) => {
//   try {
//     console.log("params", params);
//     params.setLoader(true);
//     const response = await loginRepo({
//       name: params.name,
//       password: params.password,
//       email: params.email,
//       device_type: params.device_type,
//       device_token: params.device_token,
//     });
//     if (response.status === true) {
//       params.setLoader(false);
//       console.log("response", response?.body?.data);
//       ApiClient.setAuthHeader(response?.body?.data?.api_token);
//       params.dispatch(saveMeHome(true));
//       params.dispatch(saveToken(response?.body?.data?.api_token));
//       params.dispatch(profileData(response?.body?.data?.user));
//       if (!params.onboarding) {
//         params.navigation("OnBoarding", { type: true });
//       } else {
//         params.navigation("Home");
//       }
//       params.setEmail("");
//       params.setPassword("");
//       //params.navigation("Subscription");
//     } else if (response.status === false) {
//       params.setLoader(false);
//       AlertToast(response.message);
//       console.log(console.log("responsefalse", response));
//     }
//   } catch (error) {
//     params.setLoader(false);
//   }
// };


export const signInModel = async (params: any) => {
  params.setLoader(true);
    try {
      const res:any = await ApiClient.auth.login({
        "email": params.email,
    "password": params.password
      })
  
      console.log("login response",res.data.data);
    
      if(res.data.status == 200 && res.data.status){
        params.setLoader(false);
            ApiClient.setAuthHeader(res?.data?.data?.token);
              params.dispatch(saveMeHome(true));
           params.dispatch(saveToken(res?.data?.data?.token));
           getUserProfileModel({dispatch:params.dispatch})
        //       params.dispatch(profileData(response?.body?.data?.user));
              if (res?.data?.data?.isAccountVerified) {
                  params.navigation("Home");
                } else {
                params.navigation("OtpVerify",{email:params.email})
              }
              params.setEmail("");
              params.setPassword("");
      }
        else{
            params.setLoader(false);
          toasito(res?.data?.message?res?.data?.message:res.message)
      }
      
    } catch (error:any) {
      params.setLoader(false);
     toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
  }
  };
  
  