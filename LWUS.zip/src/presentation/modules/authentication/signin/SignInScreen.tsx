import React, { useState, useEffect, useRef } from "react";
import {
  Modal,
  StyleSheet,
  KeyboardAvoidingView,
  View,
  Image,
  TextInput,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  Animated,
  Pressable,
  Alert,
  ImageBackground,
  Platform,
  StatusBar,
  Easing,
  BackHandler,
} from "react-native";
import Images from "../../../../app/utils/Images";
import StyledInput from "../../../components/StylesInput";
import Colors from "../../../../app/utils/Colors";
import { HEIGHT, WIDTH } from "../../../../app/utils/AppConstants";
import Fonts from "../../../../app/utils/Fonts";
import CheckBox from "@react-native-community/checkbox";
import MyCheckBox from "../../../components/MyCheckBox";
import { StyledText } from "../../../components/StyledText";
import { navigate } from "../../../navigation/NavigationService";
import { Spacer } from "../../../components/Spacer";
import StyledButton from "../../../components/StyledButton";
import { useDispatch, useSelector } from "react-redux";
// import { signin } from "./SignInViewModel";
import { platform } from "os";
import { useIsFocused } from "@react-navigation/native";
import { toasito } from "../../../../app/utils/Extensions";
import { allLanguages, check, rememberMeAction } from "../../../../app/redux/slice";
import { signInModel } from "./SignInViewModel";
import { getAllLanguagesModel } from "../signup/SignUpViewModel";

type Props = {
  navigation: any;
};

const SignInScreen: React.FC<Props> = (props) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [rememberMe, setRememberMe] = React.useState(false);
  const SlideUpAnimation = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [email, setEmail] = useState("tameer@gmail.com");
  const [password, setPassword] = useState("123456789");
  const [loader, setLoader] = useState(false);
  const deviceType = Platform.OS === "android" ? "android" : "ios";
  const currrentScreen = props.navigation?.getState()?.routeNames[0];
  const dispatch = useDispatch();
  const isFocused = useIsFocused();

  const [validationError, setValidationError] = useState();

  const selectCondition = useSelector(
    (state: any) => state?.UseData?.condition
  );
  console.log("selectCondition", selectCondition);
  const [counter, setCounter] = useState<number>(0);
 
  const onboarding = useSelector((state: any) => state?.UseData?.onbording);
  const savedEmail = useSelector((state: any) => state?.UseData?.email);
  console.log("onboarding", onboarding);
  const savedPassword = useSelector((state: any) => state?.UseData?.password);



  var stateArr: {value: string; label: string}[] = [];
  const [languages, setLanguages] = useState(); 

  const stateListFunction = array => {



   


    array?.map((val: {id: string; name: string}) => {
      stateArr.push({
        value: val.id,
        label: val.name,
      });
    });
    return stateArr;
  };
  useEffect(() => {
   
    getAllLanguagesModel({setLanguages: setLanguages}).then(() => {
      console.log("Languages:", languages);
      
      const stateData = stateListFunction(languages);
      console.log("statedata:", stateData);
      dispatch(allLanguages(stateData));
       // Update items2 with state data
    });
  }, []);

 
  console.log("current screeen", currrentScreen);
 

  useEffect(() => {
    if (currrentScreen == "Splash" && isFocused) {
      const backAction = () => {
        setCounter(counter + 1);

        if (counter == 0) {
          toasito("Tap again to exit");
        } else if (counter == 1) {
          BackHandler.exitApp();

          setCounter(0);
        }

        return true;
      };

      const backHandler = BackHandler.addEventListener(
        "hardwareBackPress",

        backAction
      );

      return () => backHandler.remove();
    }
  }, [counter, isFocused]);

  useEffect(() => {
    if (currrentScreen == "Splash") {
      if (selectCondition) {
        setEmail(savedEmail);
        setPassword(savedPassword);
      } else {
        setEmail("");
        setPassword("");
      }
    }
  }, [isFocused]);
  useEffect(() => {
    const logoAnimation = Animated.timing(SlideUpAnimation, {
      toValue: 0,
      duration: 900,
      easing: Easing.easeOutCubic,
      useNativeDriver: true,
    });

    const fadeInAnimation = Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 100,
      easing: Easing.linear,
      useNativeDriver: true,
    });

    Animated.sequence([logoAnimation, fadeInAnimation]).start(() => {
      // Once the animations are complete, show the modal view
      setModalVisible(true);
    });
  }, [fadeAnim]);

  function displayModal() {
    setModalVisible(!modalVisible);
  }
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor="transparent" hidden />
      <View style={[styles.imageBgStyle, ,]}>
        <ImageBackground
          style={[styles.imageBgStyle, { alignItems: "center", zIndex: 1 }]}
          source={Images.IcLoginBg}
        >
          <Image
            style={[
              styles.logoStyle,
            ]}
            source={Images.IcSplash}
          />
        </ImageBackground>
        <View style={[styles.modalView]}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ marginTop: 25 }}
          >
            <StyledInput
              // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}     //   clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
              // error={{status:true,message:"something went wrong"}}
              headerText="Email"
              placeholderText="name@domain.com"
              secureTextEntry={false}
              value={email}
              onChange={(val) => {
                if (
                  /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val) &&
                  val !== ""
                ) {
                  setEmail(val);

                  setValidationError(false);
                } else {
                  setEmail(val);

                  setValidationError(true);
                }
              }}
              type="email-address"
              textStyle={{
                color: Colors.black,
                fontFamily: Fonts.Medium,
                fontSize: Fonts.large_font,
              }}
              leftIcon={<Image style={styles.icons} source={Images.IcEmail} />}
            />
            {validationError ? (
              <StyledText
                text={"Invalid Email*"}
                style={{
                  margin: 5,

                  color: "red",

                  fontSize: 13,
                }}
              />
            ) : null}
            <Spacer margin={"4%"} />
            <StyledInput
              headerText="Password"
              placeholderText="********"
              secureTextEntry={true}
              value={password}
              onChange={setPassword}
              // error={{status:true,message:"something went wrong"}}
              textStyle={{
                color: Colors.black,
                fontFamily: Fonts.Medium,
                fontSize: Fonts.large_font,
              }}
              leftIcon={<Image style={styles.icons} source={Images.IcLock} />}
              rightIcon={
                <Image style={styles.icons} source={Images.IcEyesOff} />
              }
            />
            <View style={styles.checkBoxContainer}>
              <View
                style={[
                  styles.innerCheckBox,
                  {
                    flexWrap: "wrap",
                  },
                ]}
              >
                {Platform.OS === "android" ? (
                  <CheckBox
                    disabled={false}
                    value={selectCondition}
                    tintColor={Colors.green}
                    onCheckColor={Colors.green}
                    onTintColor={Colors.green}
                    boxType={"square"}
                    onValueChange={(newValue) => dispatch(check(newValue))}
                    tintColors={{
                      true: Colors.green,
                      false: Colors.green,
                    }}
                  />
                ) : (
                  <MyCheckBox
                    value={selectCondition}
                    onChange={setRememberMe}
                  />
                )}
                <StyledText text="Remember Me" extraStyle={styles.rememberMe} />
              </View>
              <Pressable
                onPress={() =>
                  navigate("ForgotPassword", { title: "Forgot Password" })
                }
              >
                <Spacer margin={"2.5%"} />
                <StyledText
                  text="Forgot Password?"
                  extraStyle={styles.forgot}
                />
              </Pressable>
            </View>
            <View style={{ flex: 1, alignItems: "center" }}>
              <StyledButton
                title="SIGN IN"
                isLoading={loader}
                btnContStyle={{ marginVertical: 25 }}
                 onPress={() => {
                
                  signInModel({email:email, password:password,
                    setLoader: setLoader,
                        navigation: navigate,
                        dispatch: dispatch,
                        setEmail: setEmail,
                        setPassword: setPassword,})
                        if (selectCondition === true) {
                              dispatch(
                                rememberMeAction({
                                  email: email,
                                  password: password,
                                })
                              );
                            } else if (selectCondition === false) {
                              dispatch(
                                rememberMeAction({
                                  email: "",
                                  password: "",
                                })
                              );
                            }
                //   //navigate("OnBoarding", { type: true })
                //   signin({
                //     name: "user",
                //     password: password,
                //     email: email,
                //     device_type: deviceType,
                //     device_token: firebaseToken,
                //     setLoader: setLoader,
                //     navigation: navigate,
                //     dispatch: dispatch,
                //     setEmail: setEmail,
                //     setPassword: setPassword,
                //     onboarding: onboarding,
                //   });
                //   if (selectCondition === true) {
                //     dispatch(
                //       rememberMeAction({
                //         email: email,
                //         password: password,
                //       })
                //     );
                //   } else if (selectCondition === false) {
                //     dispatch(
                //       rememberMeAction({
                //         email: "",
                //         password: "",
                //       })
                //     );
                //   }
                 }}
              />
              <Pressable
                style={styles.bottomContainer}
                onPress={() => navigate("SignUp")}
              >
                <StyledText
                  text="Don't have an account?"
                  extraStyle={styles.signup1}
                />
                <StyledText text=" Sign Up" extraStyle={styles.signup2} />
              </Pressable>
            </View>
          </ScrollView>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  imageBgStyle: { width: "100%", height: 360, alignItems: "center" },
  logoStyle: {
    top: 24,
    width: 144,
    height: 165,
  },
  icons: { width: 20, height: 20, resizeMode: "contain" },
  loginFormStyle: {
    height: 22,
    backgroundColor: "red",

    paddingHorizontal: 20,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
    position: "absolute",
    bottom: 0,
  },
  modalView: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    height: HEIGHT / 1.3,
    width: WIDTH / 1.1,
    backgroundColor: "white",
    position: "absolute",
    top: 210,
    zIndex: 999,
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  container1: {
    width: WIDTH / 2,
    padding: 25,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  button1: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    backgroundColor: "#2AC062",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  logoContainer: {
    alignItems: "center",
    zIndex: 1,
    flex: 1,
    justifyContent: "center",
  },

  closeButton: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FF3974",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 22,
  },
  image: {
    marginTop: 150,
    marginBottom: 10,
    width: "100%",
    height: 350,
  },
  text: {
    fontSize: 24,
    marginBottom: 30,
    padding: 40,
  },
  checkBoxContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginTop: 10,
  },
  innerCheckBox: { flexDirection: "row", alignItems: "center" },
  rememberMe: { color: Colors.black, fontFamily: Fonts.Medium },
  forgot: {
    color: Colors.black,
    textDecorationLine: "underline",
    fontFamily: Fonts.Medium,
  },
  signup1: {
    color: Colors.grey,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
  },
  signup2: {
    color: Colors.green,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
    fontFamily: Fonts.SemiBold,
  },
  bottomContainer: {
    marginTop: 80,
    flexDirection: "row",
    justifyContent: "center",
    paddingBottom: 20,
  },
});
export default SignInScreen;
