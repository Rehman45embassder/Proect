export interface LoginRequest {
  name: string;
  password: string;
  email: string;
  device_type: string;
  device_token: string;
  setLoader?: Any;
  navigation?: any;
  dispatch?: any;
}
