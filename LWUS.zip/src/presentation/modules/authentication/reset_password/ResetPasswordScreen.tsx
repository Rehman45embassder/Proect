import React, { useState, useEffect, useRef } from "react";
import {
  Modal,
  StyleSheet,
  KeyboardAvoidingView,
  View,
  Image,
  TextInput,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  Animated,
  Pressable,
  Alert,
  ImageBackground,
  Platform,
  StatusBar,
} from "react-native";
import Images from "../../../../app/utils/Images";
import StyledInput from "../../../components/StylesInput";
import Colors from "../../../../app/utils/Colors";
import { HEIGHT, WIDTH } from "../../../../app/utils/AppConstants";
import Fonts from "../../../../app/utils/Fonts";
import CheckBox from "@react-native-community/checkbox";
import MyCheckBox from "../../../components/MyCheckBox";
import { StyledText } from "../../../components/StyledText";
import { navigate } from "../../../navigation/NavigationService";
import { Spacer } from "../../../components/Spacer";
import StyledButton from "../../../components/StyledButton";
import TitleBar from "../../../components/TitleBar";
import Dialogs from "../../../components/Dialogs";
// import { ResetPasswordViewModel } from "./ResetPasswordViewModel";
import { useSelector } from "react-redux";
import { toasito } from "../../../../app/utils/Extensions";
import { ResetPasswordViewModel } from "./ResetPasswordViewModel";

type Props = {
  navigation: any;
  route?: {
    params?: any;
  };
};

const ResetPasswordScreen: React.FC<Props> = (props) => {
  const [modal, setModal] = React.useState(false);
  const [rememberMe, setRememberMe] = React.useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loader, setLoader] = useState(false);
  const profileData = useSelector((state: any) => state?.UseData?.profileInfo);
  const [email, setEmail] = useState(props?.route?.params?.email);
  const SlideUpAnimation = useRef(new Animated.Value(1)).current;
  const [validationError1, setValidationError1] = useState();

  return (
    <View style={styles.container}>
      <StatusBar hidden={true} />
      <View style={[styles.imageBgStyle]}>
        <ImageBackground
          style={[styles.imageBgStyle, { alignItems: "center", zIndex: 1 }]}
          source={Images.IcLoginBg}
        >
          <Spacer margin={"5%"} />
          <TitleBar title="RESET PASSWORD" onPressBack={() => {navigate("ForgotPassword")}} />

          <View style={[styles.modalView]}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ marginTop: 25 }}
            >
              <Spacer margin={"10%"} />

              <StyledInput
                headerText="New Password"
                placeholderText="********"
                secureTextEntry={true}
                value={password}
  containerStyle={{ height: HEIGHT / 15 }}
  headerText="Password"
  placeholderText="********"
  secureTextEntry={true}
  value={password}
  onChange={(val) => {
    if (
      /^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^a-zA-Z\d\s:])(.{8,16})$/.test(val) &&
      val !== ""
    ) {
      setPassword(val);
      setValidationError1(false);
    } else {
      setPassword(val);
      setValidationError1(true);
    }
  }}
  textStyle={{
    color: Colors.black,
    fontFamily: Fonts.Medium,
    fontSize: Fonts.large_font,
  }}
  leftIcon={<Image style={styles.icons} source={Images.IcLock} />}
  rightIcon={<Image style={styles.icons} source={Images.IcEyesOff} />}
/>
{validationError1 ? (
                      <StyledText
                        text={"New Password must contain at least one Uppercase letter, one Lowercase letter, one Number, and one Special character"}
                        style={{
                          margin: 5,
      
                          color: "red",
      
                          fontSize: 13,
                        }}
                      />
                    ) : null}
              <Spacer margin={"4%"} />
              <StyledInput
                headerText="Confirm Password"
                placeholderText="********"
                secureTextEntry={true}
                value={confirmPassword}
                onChange={setConfirmPassword}
                // error={{status:true,message:"something went wrong"}}
                textStyle={{
                  color: Colors.black,
                  fontFamily: Fonts.Medium,
                  fontSize: Fonts.large_font,
                }}
                leftIcon={<Image style={styles.icons} source={Images.IcLock} />}
                rightIcon={
                  <Image style={styles.icons} source={Images.IcEyesOff} />
                }
              />

              <View style={{ flex: 1, alignItems: "center" }}>
                <Spacer margin={"5%"} />
                <StyledButton
                  title="Verify"
                  btnContStyle={{ marginVertical: 25 }}
                  onPress={() => {if(password===confirmPassword) 
                    ResetPasswordViewModel({
                      setModal: setModal,
                      email: email,
                     password: password,
                      setLoader: setLoader,
                    })
                  else{toasito("Confirm Password Not Matched")}}
                  }
                />
                <Dialogs
                  visible={modal}
                  onClose={() => setModal(!modal)}
                  onBtn2Press={() => {
                    setModal(!modal);
                    navigate("SignIn");
                  }}
                  popup
                  checkIcon
                  title="PASSWORD UPDATED!"
                  btn2="Ok"
                  description={
                    "Your password has been successfully changed. Please login with your new password."
                  }
                />
              </View>
            </ScrollView>
          </View>
        </ImageBackground>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  imageBgStyle: { width: "100%", height: 360 },
  logoStyle: {
    top: 24,
    width: 144,
    height: 165,
  },
  icons: { width: 20, height: 20, resizeMode: "contain" },
  loginFormStyle: {
    height: 22,
    backgroundColor: "red",

    paddingHorizontal: 20,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
    position: "absolute",
    bottom: 0,
  },
  modalView: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    height: HEIGHT / 1.3,
    width: WIDTH / 1.1,
    backgroundColor: "white",
    position: "absolute",
    top: 210,
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  container1: {
    width: WIDTH / 2,
    padding: 25,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  button1: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    backgroundColor: "#2AC062",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  closeButton: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FF3974",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 22,
  },
  image: {
    marginTop: 150,
    marginBottom: 10,
    width: "100%",
    height: 350,
  },
  text: {
    fontSize: 24,
    marginBottom: 30,
    padding: 40,
  },
  checkBoxContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginTop: 10,
  },
  innerCheckBox: { flexDirection: "row", alignItems: "center" },
  rememberMe: { color: Colors.black, fontFamily: Fonts.Medium },
  forgot: {
    color: Colors.black,
    textDecorationLine: "underline",
    fontFamily: Fonts.Medium,
  },
  signup1: {
    color: Colors.grey,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
  },
  signup2: {
    color: Colors.green,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
    fontFamily: Fonts.SemiBold,
  },
  bottomContainer: {
    marginTop: 80,
    flexDirection: "row",
    justifyContent: "center",
    paddingBottom: 20,
  },
  imgContainer: {
    marginTop: 25,
    marginBottom: HEIGHT / 30,
    alignItems: "center",
  },
  mainLogo: { width: 240, height: 80 },
  title: {
    fontSize: Fonts.xmedium_font,
    color: Colors.Seventy,
    alignSelf: "center",
    fontFamily: Fonts.Medium,
    width: 315,
  },
});

export default ResetPasswordScreen;
