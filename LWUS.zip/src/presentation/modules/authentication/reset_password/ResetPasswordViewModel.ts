// import { Alert } from "react-native";
// import { AlertToast, toasito } from "../../../../app/utils/Extensions";

import { BASEURL } from "../../../../app/utils/AppConstants";
import { toasito } from "../../../../app/utils/Extensions";
import { navigateClear } from "../../../navigation/NavigationService";

// import ApiClient from "../../../../data/networking/ApiClient";
// import { ResetPassword } from "./type";
// import {
//   ForgetPasswordRepo,
//   ResetPasswordRepo,
// } from "../../../../domain/repository/Repository";

export const ResetPasswordViewModel = async (params: ResetPassword) => {
  
   
    try {

        console.log("params", params);
        params.setLoader(true);
    
     
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    
    const raw = JSON.stringify({ "email":params.email,"password":params.password });
    
    const requestOptions = {
    method: "PATCH",
    headers: myHeaders,
    body:raw,
    redirect: "follow"
    };
    
      const res:any =await fetch(`${BASEURL}auth/reset-password`, requestOptions)
      const response=await res.json();
    
        console.log("otp account2",response);
      
        if(response.status == 200 && response.status) {
          params.setLoader(false);
          console.log("response", response);
           params.setModal(true);
          
    
          //params.navigation("Subscription");
        } else  {
          params.setLoader(false);
          toasito(response.message);
          console.log("responsefalse", response);
        }
      } catch (error:any) {
        if(error?.response?.data?.message=='Unauthenticated.'){
          navigateClear("SignIn");
        }
       toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
    }
};
