export interface ResetPassword {
  setLoader?: Any;
  navigation?: any;
  dispatch?: any;
  email?: string;
  new_password?: string;
  confirm_password?: string;
}
