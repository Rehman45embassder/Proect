import React, { useState, useEffect, useRef } from "react";
import {
  Modal,
  StyleSheet,
  KeyboardAvoidingView,
  View,
  Image,
  TextInput,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  Animated,
  Pressable,
  Alert,
  ImageBackground,
  Platform,
  StatusBar,
} from "react-native";
import Images from "../../../../app/utils/Images";
import StyledInput from "../../../components/StylesInput";
import Colors from "../../../../app/utils/Colors";
import { HEIGHT, WIDTH } from "../../../../app/utils/AppConstants";
import Fonts from "../../../../app/utils/Fonts";
import CheckBox from "@react-native-community/checkbox";
import MyCheckBox from "../../../components/MyCheckBox";
import { StyledText } from "../../../components/StyledText";
import { navigate } from "../../../navigation/NavigationService";
import { Spacer } from "../../../components/Spacer";
import StyledButton from "../../../components/StyledButton";
import TitleBar from "../../../components/TitleBar";
import Dialogs from "../../../components/Dialogs";
import { ForgetPasswordViewModel } from "./ForgetPasswordViewModel";
// import { ForgetPasswordViewModel } from "./ForgetPasswordViewModel";

type Props = {
  navigation: any;
};

const ForgotPasswordScreen: React.FC<Props> = (props) => {
  const [modal, setModal] = React.useState(false);
  const [rememberMe, setRememberMe] = React.useState(false);
  const [email, setEmail] = useState("");
  const [loader, setLoader] = React.useState(false);
  const [validationError, setValidationError] = useState();
  const SlideUpAnimation = useRef(new Animated.Value(1)).current;

  return (
    <View style={styles.container}>
      <StatusBar hidden={true} />
      <View style={[styles.imageBgStyle]}>
        <ImageBackground
          style={[styles.imageBgStyle, { alignItems: "center", zIndex: 1 }]}
          source={Images.IcLoginBg}
        >
          <Spacer margin={"5%"} />
          <TitleBar
            title="FORGOT PASSWORD"
            onPressBack={() => navigate("SignIn")}
          />

          <View style={[styles.modalView]}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ marginTop: 25 }}
            >
              <Spacer margin={"3%"} />
              <StyledText
                extraStyle={styles.title}
                text={
                  "Please enter your email address to get 4- digit code to reset your password."
                }
              />
              <Spacer margin={"10%"} />
              <StyledInput
                // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}     //   clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                // error={{status:true,message:"something went wrong"}}
                headerText="Email"
                placeholderText="name@domain.com"
                secureTextEntry={false}
                value={email}
                onChange={(val) => {
                  if (
                    /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val) &&
                    val !== ""
                  ) {
                    setEmail(val);

                    setValidationError(false);
                  } else {
                    setEmail(val);

                    setValidationError(true);
                  }
                }}
                type="email-address"
                textStyle={{
                  color: Colors.black,
                  fontFamily: Fonts.Medium,
                  fontSize: Fonts.large_font,
                }}
                leftIcon={
                  <Image style={styles.icons} source={Images.IcEmail} />
                }
              />
              {validationError ? (
                <StyledText
                  text={"Invalid Email*"}
                  style={{
                    margin: 5,

                    color: "red",

                    fontSize: 13,
                  }}
                />
              ) : null}
              <View style={{ flex: 1, alignItems: "center" }}>
                <Spacer margin={"5%"} />
                <StyledButton
                  isLoading={loader}
                  title="SEND"
                  btnContStyle={{ marginVertical: 25 }}
                  onPress={() =>
                    ForgetPasswordViewModel({
                      email: email,
                      setLoader: setLoader,
                      setModal: setModal,
                    })
                  }
                />
                <Dialogs
                  visible={modal}
                  onClose={() => setModal(!modal)}
                  onBtn2Press={() => {
                    setModal(!modal);
                    navigate("OtpVerify", { reset: true, email: email });
                  }}
                  popup
                  checkIcon
                  title="REQUEST SUCCESSFUL!"
                  btn2="Ok"
                  description={
                    "Your 4-digit code has been sent to your email address."
                  }
                />
              </View>
            </ScrollView>
          </View>
        </ImageBackground>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  imageBgStyle: { width: "100%", height: 360 },
  logoStyle: {
    top: 24,
    width: 144,
    height: 165,
  },
  icons: { width: 20, height: 20, resizeMode: "contain" },
  loginFormStyle: {
    height: 22,
    backgroundColor: "red",

    paddingHorizontal: 20,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
    position: "absolute",
    bottom: 0,
  },
  modalView: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    height: HEIGHT / 1.3,
    width: WIDTH / 1.1,
    backgroundColor: "white",
    position: "absolute",
    top: 210,
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  container1: {
    width: WIDTH / 2,
    padding: 25,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  button1: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    backgroundColor: "#2AC062",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  closeButton: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FF3974",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 22,
  },
  image: {
    marginTop: 150,
    marginBottom: 10,
    width: "100%",
    height: 350,
  },
  text: {
    fontSize: 24,
    marginBottom: 30,
    padding: 40,
  },
  checkBoxContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginTop: 10,
  },
  innerCheckBox: { flexDirection: "row", alignItems: "center" },
  rememberMe: { color: Colors.black, fontFamily: Fonts.Medium },
  forgot: {
    color: Colors.black,
    textDecorationLine: "underline",
    fontFamily: Fonts.Medium,
  },
  signup1: {
    color: Colors.grey,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
  },
  signup2: {
    color: Colors.green,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
    fontFamily: Fonts.SemiBold,
  },
  bottomContainer: {
    marginTop: 80,
    flexDirection: "row",
    justifyContent: "center",
    paddingBottom: 20,
  },
  imgContainer: {
    marginTop: 25,
    marginBottom: HEIGHT / 30,
    alignItems: "center",
  },
  mainLogo: { width: 240, height: 80 },
  title: {
    fontSize: Fonts.xmedium_font,
    color: Colors.Seventy,
    alignSelf: "center",
    fontFamily: Fonts.Medium,
    width: WIDTH / 1.3,
  },
});

export default ForgotPasswordScreen;
