export interface ForgetPassword {
  setLoader?: any;
  navigation?: any;
  dispatch?: any;
  email?: string;
}
