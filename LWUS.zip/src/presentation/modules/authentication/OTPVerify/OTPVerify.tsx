import React, { useState } from "react";
import {
  ImageBackground,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
} from "react-native";
import MyView from "../../../components/MyView";
import {
  CodeField,
  Cursor,
  useBlurOnFulfill,
  useClearByFocusCell,
} from "react-native-confirmation-code-field";
import Fonts from "../../../../app/utils/Fonts";
import Colors from "../../../../app/utils/Colors";
import { StyledText } from "../../../components/StyledText";
import { View } from "react-native";
import StyledButton from "../../../components/StyledButton";
import Dialogs from "../../../components/Dialogs";
import { navigate, navigateClear } from "../../../navigation/NavigationService";
import { Spacer } from "../../../components/Spacer";
import TitleBar from "../../../components/TitleBar";
import Images from "../../../../app/utils/Images";
import { HEIGHT, WIDTH } from "../../../../app/utils/AppConstants";

// import {
//   OTPVerifyForgetPasswordViewModel,
//   OTPVerifyViewModel,
//   ResendOTPVerifyViewModel,
//   ResendOTPViewModel,
// } from "./OTPVerifyViewModel";
import { useSelector } from "react-redux";
import { OTPVerifyForgetPasswordViewModel, OTPVerifyViewModel } from "./OTPVerifyViewModel";


type Props = {
  navigation?: any;
  route?: {
    params?: any;
  };
};

const OTPVerify: React.FC<Props> = ({ navigation, route }) => {
  const prop = route?.params;
  console.log("params OTP", prop);
  const [modal, setModal] = React.useState(false);
  const [modal2, setModal2] = React.useState(false);
  const [modal3, setModal3] = React.useState(false);
  const [modal4, setModal4] = React.useState(false);
  const [modal5, setModal5] = React.useState(false);
  const [modal6, setModal6] = React.useState(false);
  const [modal7, setModal7] = React.useState(false);
  const [modal8, setModal8] = React.useState(false);
  const [loader, setLoader] = useState(false);
  const profileData = useSelector((state: any) => state?.UseData?.profileInfo);
  const [email, setEmail] = useState(route?.params?.email);
  console.log("email inside otp", email);
  const CELL_COUNT = 4;
  const [value, setValue] = React.useState("");
  const ref = useBlurOnFulfill({ value, cellCount: CELL_COUNT });
  const [props, getCellOnLayoutHandler] = useClearByFocusCell({
    value,
    setValue,
  });
  console.log("value OTP", value);
  return (
    <View style={styles.container}>
      <StatusBar hidden={true} />
      <View style={[styles.imageBgStyle]}>
        <ImageBackground
          style={[styles.imageBgStyle, { alignItems: "center", zIndex: 1 }]}
          source={Images.IcLoginBg}
        >
          <Spacer margin={"5%"} />
          <TitleBar
            title="OTP"
            onPressBack={() =>
              prop?.changePass
                ? navigate("ChangePassword")
                : prop?.reset?"": navigateClear("SignIn")
            }
          />
        </ImageBackground>
        <View style={[styles.modalView]}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ marginTop: 10 }}
          >
            <View style={styles.titleView}>
              <StyledText
                text={"VERIFICATION CODE"}
                extraStyle={styles.title2}
              />
            </View>
            <StyledText
              extraStyle={styles.title}
              text={"Please enter your 4-digit verification code"}
            />
            <View>
              <CodeField
                ref={ref}
                {...props}
                // Use `caretHidden={false}` when users can't paste a text value, because context menu doesn't appear
                value={value}
                onChangeText={setValue}
                cellCount={CELL_COUNT}
                keyboardType="number-pad"
                textContentType="oneTimeCode"
                renderCell={({ index, symbol, isFocused }) => (
                  <Text
                    key={index}
                    style={[styles.cell, isFocused && styles.focusCell]}
                    onLayout={getCellOnLayoutHandler(index)}
                  >
                    {symbol || (isFocused ? <Cursor /> : null)}
                  </Text>
                )}
              />
            </View>
            <View style={{height:HEIGHT/2}}>            
              <StyledButton
              isLoading={loader}
              title="Verify"
              btnContStyle={styles.button}
              onPress={() => 
                prop?.reset? OTPVerifyForgetPasswordViewModel({
                  email: email,
token:value,
                  setLoader: setLoader,
                  navigation:navigate
                }):
                OTPVerifyViewModel({
                  email: email,
token:value,
                  setLoader: setLoader,
                  setModal: setModal,
                })
              }
              
            />
</View>

            <Dialogs
              visible={modal}
              checkIcon
              onClose={() => setModal(!modal)}
              onBtn2Press={() => {
                navigate("Home");
                setModal(!modal);
              }}
              popup
              title="ACCOUNT VERIFIED!"
              btn2="Ok"
              description={"Your account has been verified."}
            />
            <Dialogs
              visible={modal2}
              onClose={() => setModal2(!modal2)}
              onBtn2Press={() => {
                setModal2(!modal2);
                
              }}
              popup
              checkIcon
              title="REQUEST SUCCESSFUL!"
              btn2="Ok"
              description={
                "Your 6-digit code has been sent to your email address."
              }
            />
            <Dialogs
              visible={modal3}
              onClose={() => setModal3(!modal3)}
              onBtn2Press={() => {
                setModal3(!modal3);
                navigate("Home");
              }}
              checkIcon
              popup
              title="PASSWORD UPDATED!"
              btn2="Ok"
              description={"Your password has been changed successfully."}
            />

            <Dialogs
              checkIcon
              Icon={Images.IcDeleteAccount}
              visible={modal4}
              onClose={() => setModal4(!modal4)}
              onBtn1Press={() => {
                setModal4(!modal4);
              }}
              onBtn2Press={() => {
                setModal4(!modal4);
                setModal5(!modal5);
              }}
              popup
              title="DELETE ACCOUNT"
              btn1="No"
              btn2="Yes"
              description={
                'Are you sure that you want to DELETE your account? If "YES", you will lose all information and history from your account. Do you still want to continue?'
              }
            />
            <Dialogs
              checkIcon
              Icon={Images.IcDeleteAccount}
              visible={modal6}
              onClose={() => setModal6(!modal6)}
              onBtn1Press={() => {
                setModal6(!modal6);
              }}
              onBtn2Press={() => {
                setModal6(!modal6);
                navigate("SignIn");
              }}
              popup
              title="ACCOUNT DELETED"
              btn2="OK"
              description={"your account has been deleted successfully."}
            />
            <Dialogs
              checkIcon
              Icon={Images.IcDeleteAccount}
              visible={modal5}
              onClose={() => setModal5(!modal5)}
              onBtn1Press={() => {
                setModal5(!modal5);
              }}
              onBtn2Press={() => {
                setModal5(!modal5);
               
              }}
              popup2
              title="DELETE ACCOUNT"
              btn1="No"
              btn2="Yes"
              description={
                "Are you sure that you would like to DELETE your account (all history will be deleted immediately after this step and will be unrecoverable afterwards)? If so, click YES"
              }
            />

            <Dialogs
              checkIcon
              Icon={Images.IcClose}
              visible={modal7}
              onClose={() => setModal7(!modal7)}
              onBtn1Press={() => {
                setModal7(!modal7);
              }}
              onBtn2Press={() => {
                setModal7(!modal7);
                // setModal8(!modal8);
              }}
              popup
              title="CANCEL SUBSCRIPTION"
              btn1="No"
              btn2="Yes"
              description={
                "Are you sure, you want to cancel your subscription?"
              }
            />
            <Dialogs
              Icon={Images.IcClose}
              checkIcon
              visible={modal8}
              onClose={() => setModal8(!modal8)}
              onBtn1Press={() => {
                setModal7(!modal7);
                setModal8(!modal8);
              }}
              onBtn2Press={() => {
                navigate("Home");
                setModal8(!modal8);
              }}
              popup
              title="SUBSCRIPTION CANCELLED"
              btn1="No"
              btn2="Yes"
              description={
                "Your subscription has been cancelled you can use the app until the last date of expiration."
              }
            />
          </ScrollView>
        </View>
      </View>
    </View>
  );
};

export default OTPVerify;

const styles = StyleSheet.create({
  titleView: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 30,
  },
  title: {
    fontSize: Fonts.large_font - 2,
    color: Colors.Seventy,
    textAlign: "center",
    alignSelf: "center",
    marginHorizontal: 1,
    marginBottom: 40,
    fontFamily: Fonts.Regular,
    width: "90%",
  },
  button: { marginTop: 60, height: "11%", width: "63%", alignSelf: "center" },
  text3: {
    fontSize: Fonts.large_font - 1,
    color: Colors.green,
    alignSelf: "center",
    textDecorationLine: "underline",
    fontFamily: Fonts.Medium,
    marginVertical: 35,
  },
  title2: {
    color: Colors.blackOpacity,
    fontSize: Fonts.xxxlarge_font,
    fontFamily: Fonts.SemiBold,
    marginVertical: 20,
  },
  cell: {
    width: 45,
    height: 65,
    borderRadius: 8,
    fontSize: 46,
    borderWidth: 1,
    borderColor: Colors.green,
    textAlign: "center",
    color: Colors.Seventy,
    fontFamily: Fonts.Regular,
  },
  focusCell: {
    borderColor: "#000",
  },
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  imageBgStyle: { width: "100%", height: 320, alignItems: "center" },
  modalView: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 1,
    height: HEIGHT / 1.3,
    width: WIDTH / 1.1,

    backgroundColor: "white",
    position: "absolute",
    top: HEIGHT / 5,
    zIndex: 999,
  },
});
