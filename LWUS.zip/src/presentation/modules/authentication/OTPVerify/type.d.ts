export interface VerifyOTP {
  otp_code?: string;
  email?: string;
  setLoader?: Any;
  navigation?: any;
  dispatch?: any;
}

export interface ForgetPasswordVerifyOTP {
  code?: string;
  email?: string;
  setLoader?: Any;
  navigation?: any;
  dispatch?: any;
}

export interface resendOTP {
  email?: string;
  setLoader?: Any;
}
