// import { Alert } from "react-native";
// import { AlertToast, toasito } from "../../../../app/utils/Extensions";

import { store } from "../../../../app/redux/store";
import { BASEURL } from "../../../../app/utils/AppConstants";
import { toasito } from "../../../../app/utils/Extensions";
import ApiClient from "../../../../data/networking/ApiClient";
import { navigateClear } from "../../../navigation/NavigationService";

// import ApiClient from "../../../../data/networking/ApiClient";

// import {
//   ForgetPasswordOPTVerifyRepo,
//   ForgetPasswordRepo,
//   ResendOTPRepo,
//   VerifyOTPRepo,
// } from "../../../../domain/repository/Repository";
// import { VerifyOTP } from "./type";
// import { ChangePasswordViewModel } from "../../dashboard/drawer/settings/change_password/ChangePasswordViewModel";

export const OTPVerifyViewModel = async (params: any) => {

    const state = store.getState();
    const token = state?.UseData?.Token;
  try {

    console.log("params", params);
    params.setLoader(true);

    const myHeaders = new Headers();
myHeaders.append("Authorization", `Bearer ${token}`);

const requestOptions = {
    method: "GET",
    headers: myHeaders,
    redirect: "follow"
  };

  const res:any =await fetch(`${BASEURL}users/verify?token=${params.token}`, requestOptions)
  const response=await res.json();

    console.log("otp account2",response);
  
    if(response.status == 200 && response.status) {
      params.setLoader(false);
      console.log("response", response);
      if (params.navigation) {
        params.navigation;
      } else {
        params.setModal(true);
        
      }

      //params.navigation("Subscription");
    } else  {
      params.setLoader(false);
      toasito(response.message);
      console.log("responsefalse", response);
    }
  } catch (error:any) {
    if(error?.response?.data?.message=='Unauthenticated.'){
      navigateClear("SignIn");
    }
   toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
}

};

export const OTPVerifyForgetPasswordViewModel = async (params: any) => {
  
   
  try {

    console.log("params", params);
    params.setLoader(true);

 
const myHeaders = new Headers();
myHeaders.append("Content-Type", "application/json");

const raw = JSON.stringify({ "email":params.email,"token":params.token });

const requestOptions = {
method: "POST",
headers: myHeaders,
body:raw,
redirect: "follow"
};

  const res:any =await fetch(`${BASEURL}auth/verify-otp`, requestOptions)
  const response=await res.json();

    console.log("otp account2",response);
  
    if(response.status == 200 && response.status) {
      params.setLoader(false);
      console.log("response", response);
        params.navigation("ResetPassword",{email:params.email});
      

      //params.navigation("Subscription");
    } else  {
      params.setLoader(false);
      toasito(response.message);
      console.log("responsefalse", response);
    }
  } catch (error:any) {
    if(error?.response?.data?.message=='Unauthenticated.'){
      navigateClear("SignIn");
    }
   toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
}
};

// export const ResendOTPVerifyViewModel = async (params: any) => {
//   try {
//     console.log("params", params);
//     params.setLoader(true);

//     const response = await VerifyOTPRepo({
//       email: params.email,
//       otp_code: params.otp_code,
//     });
//     if (response.status === true) {
//       params.setLoader(false);
//       console.log("response", response);
//       ChangePasswordViewModel({
//         current_password: params?.userData?.currentpassword,
//         new_password: params?.userData?.newpassword,
//         confirm_password: params?.userData?.confirmpassword,
//         setLoader: params.setLoader,
//       });
//       if (params.navigation) {
//         params.navigation;
//       } else {
//         params.setModal(true);
//       }

//       //params.navigation("Subscription");
//     } else if (response.status === false) {
//       params.setLoader(false);
//       AlertToast(response.message);
//       console.log(console.log("responsefalse", response));
//     }
//   } catch (error) {
//     params.setLoader(false);
//     console.log("im inside catch of OTP");
//   }
// };
