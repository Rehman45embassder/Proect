// import { useCallback, useState } from "react";
// import { signupRepo } from "../../../../domain/repository/Repository";
// import { ErrorResponse } from "../../../../data/model/response/ErrorResponse";
// import { Dispatch } from "redux";
// import { GenericErrorMsg } from "../../../../app/utils/AppConstants";
// import { SignUpRequest } from "../../../../data/model/request/SignUpRequest";

// const SIGNUP_REQUEST = "SIGNUP_REQUEST";
// const SIGNUP_SUCCESS = "SIGNUP_SUCCESS";
// const INSPECTIONTYPE_SUCCESS = "INSPECTIONTYPE_SUCCESS";
// const SIGNUP_FAILURE = "SIGNUP_FAILURE";
// const RESET_SIGNUP_STATE = "RESET_SIGNUP_STATE";

// const signupRequest = () => ({ type: SIGNUP_REQUEST });
// const signupSuccess = (data: string) => ({
//   type: SIGNUP_SUCCESS,
//   payload: data,
// });
// const signupFailure = (error: string) => ({
//   type: SIGNUP_FAILURE,
//   payload: error,
// });
// const inspectionType = (data: string) => ({
//   type: INSPECTIONTYPE_SUCCESS,
//   payload: data,
// });
// const signupResetState = () => ({ type: RESET_SIGNUP_STATE });

// interface SignupViewModelState {
//   data: string | null;
//   loading: boolean;
//   error: string | null;
// }

// const initialSignupViewModelState: SignupViewModelState = {
//   data: null,
//   loading: false,
//   error: null,
// };

// function signupViewModelReducer(
//   state = initialSignupViewModelState,
//   action: any
// ) {
//   switch (action.type) {
//     case RESET_SIGNUP_STATE:
//       return initialSignupViewModelState;
//     case SIGNUP_REQUEST:
//       return { ...state, loading: true, error: null };
//     case SIGNUP_SUCCESS:
//       return { ...state, loading: false, data: action.payload };
//     case INSPECTIONTYPE_SUCCESS:
//       return { ...state, loading: false, data: action.payload };
//     case SIGNUP_FAILURE:
//       return { ...state, loading: false, error: action.payload };
//     default:
//       return state;
//   }
// }

// function signup(params: SignUpRequest) {
//   return async (dispatch: Dispatch) => {
//     dispatch(signupRequest());
//     try {
//       // console.log("params", params);
//       const response = await signupRepo(params);
//       if (response.status === true) {
//         dispatch(signupSuccess(response?.data));
//         //console.log("response", response);
//         params.navigation("Subscription", { SignUp: params.email });
//       } else {
//         //console.log(console.log("response1", response));

//         dispatch(signupFailure(response?.message));
//       }
//     } catch (error) {
//       if (
//         error?.response?.data?.message != null &&
//         error?.response?.data?.message !== ""
//       ) {
//         dispatch(signupFailure(error?.response?.data?.message));
//         //console.log("2");
//       } else {
//         dispatch(signupFailure(GenericErrorMsg));
//         //console.log("3");
//       }
//     }
//   };
// }

// export { signupViewModelReducer, signup, signupResetState };


import { Alert } from "react-native";

import { toasito } from "../../../../app/utils/Extensions"; 
import ApiClient from "../../../../data/networking/ApiClient";
import { navigateClear } from "../../../navigation/NavigationService";

export const getAllLanguagesModel = async (params: any) => {
  

  const myHeaders = new Headers();
myHeaders.append("Content-Type", "application/json");
const requestOptions = {
  method: "GET",
  headers: myHeaders,
  redirect: "follow"
};
  
  
     try {
        const resi:any =await fetch(`http://13.232.41.211/culturelingo/api/v1/languages`, requestOptions)
const res= await resi.json();
    console.log("AllLang123",res.data);
  
    if(res.status == 200 && res.status){
   params.setLanguages(res.data)
    }
      else{
        toasito(res?.data?.message?res?.data?.message:res.message)
    }
  } catch (error:any) {
    if(error?.response?.data?.message=='Unauthenticated.'){
      navigateClear("SignIn")
    }
   toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
}
};





export const signup = async (params: any) => {
  console.log('====================================');
  console.log("inhere",params);
  console.log('====================================');
params.setLoader(true);
  const formdata = new FormData();
formdata.append("name", params.name.toString());
formdata.append("email", params.email.toString());
formdata.append("password", params.password.toString());
formdata.append("age", params.age.toString());
formdata.append("gender",params.gender.toString());
formdata.append("city",params.city.toString());
formdata.append("country", params.country.toString());
formdata.append("languageId",params.languageId.toString());
  // Check if image is provided and append it accordingly
    if (params.image != null) {
      formdata.append('profilePicture', {
        uri: params.image,
        type: 'image/jpeg',
        name: `user_image.jpg${Math.random() * 100123123}.jpg`,
      });
    }

    console.log("inhere1");
const requestOptions = {
  method: "POST",
  body: formdata,
  redirect: "follow"
};


   try {
      console.log("form body signUP",formdata);
      const response:any =await fetch("http://13.232.41.211/culturelingo/api/v1/users", requestOptions)
      const res=await response.json();
      console.log('====================================');
      console.log("signUP",res);
      console.log('====================================');
      if(res.status == 201 && res.status){
        params.setLoader(false);
        params.setmodal(true);
      }
        else{
          params.setLoader(false);
          toasito(res?.data?.message?res?.data?.message:res.message)
      }
    } catch (error:any) {
      params.setLoader(false);
      console.log("catch signUP1",error);
      console.log("catch signUP2",error.message);
      
      console.log("catch signUP4",error.data.errors);
      console.log("catch signUP5",error.data);
      if(error?.response?.data?.message=='Unauthenticated.'){
        navigateClear("SignIn");
      }
     toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
  }

  // console.log("params",params);
  
  //   const data = new FormData();
  //   data.append('name', params.name);
  //   data.append('email', params.email);
  //   data.append("password",params.password);
  //   data.append('age', params.age.toString());
  //   data.append('gender', params.gender);
  //   data.append('city', params.city);
  //   data.append('country', params.country);
  //   data.append('languageId', params.languageId);
  
  //   // Check if image is provided and append it accordingly
  //   // if (params.image != null) {
  //   //   data.append('profilePicture', {
  //   //     uri: params.image,
  //   //     type: 'image/jpeg',
  //   //     name: `user_image.jpg${Math.random() * 100123123}.jpg`,
  //   //   });
  //   // }

  //   const headers = {
  //             // Accept: "application/json",
  //             "Content-Type": "multipart/form-data",
              
  //           };
  
  //   try {
  //     console.log("form body signUP",data);
  //     const res:any = await ApiClient.auth.signUp(data,headers)
  //     console.log('====================================');
  //     console.log("signUP",res.data.data);
  //     console.log('====================================');
  //     if(res.data.status == 200 && res.data.status){
  //       navigateClear("SignIn");
  //     }
  //       else{
  //         toasito(res?.data?.message?res?.data?.message:res.message)
  //     }
  //   } catch (error:any) {
  //     console.log("catch signUP1",error);
  //     console.log("catch signUP2",error.message);
      
  //     console.log("catch signUP4",error.data.errors);
  //     console.log("catch signUP5",error.data);
  //     if(error?.response?.data?.message=='Unauthenticated.'){
  //       navigateClear("SignIn");
  //     }
  //    toasito(error?.response?.data?.message? error?.response?.data?.message :error?.response?.data?.error?.message ? error?.response?.data?.error?.message : error?.message);
  // }
  };
  

// export const userProfileData = async (params: any) => {
//   try {
//     params.setLoader(true);
//     const response = await profileDataRepo();
//     console.warn("GET PROFILE", response);
//     if (response.status === true) {
//       params.setLoader(false);
//       // params.setText(response?.body?.data);
//       console.log("inside profile user", response);
//       // params.setProfileImage(response?.body?.data?.image),
//       //   params.SetEmail(response?.body?.data?.email),
//       //   params.SetPhone(response?.body?.data?.phone),
//       //   params.setProfileName(response?.body?.data?.name);
//       params.dispatch(profileData(response?.body?.data));

//       //params.navigation("Subscription");
//     } else if (response.status === false) {
//       params.setLoader(false);
//       console.log("inside profile user else", response);
//     }
//   } catch (error) {
//     params.setLoader(false);
//     console.log("inside profile user catch", error.message);
//   }
// };
