import React, { useState, useEffect, useRef, useLayoutEffect } from "react";
import {
  Modal,
  StyleSheet,
  KeyboardAvoidingView,
  View,
  Image,
  TextInput,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  Animated,
  Pressable,
  Alert,
  ImageBackground,
  Platform,
} from "react-native";
import Images from "../../../../app/utils/Images";
import StyledInput from "../../../components/StylesInput";
import Colors from "../../../../app/utils/Colors";
import { HEIGHT, WIDTH } from "../../../../app/utils/AppConstants";
import Fonts from "../../../../app/utils/Fonts";
import CheckBox from "@react-native-community/checkbox";
import MyCheckBox from "../../../components/MyCheckBox";
import { StyledText } from "../../../components/StyledText";
import { navigate, navigateClear } from "../../../navigation/NavigationService";
import { Spacer } from "../../../components/Spacer";
import { Dropdown } from "../../../components/react-native-element-dropdown/src"; 
import StyledButton from "../../../components/StyledButton";
import Dialogs from "../../../components/Dialogs";
import ShareDialogs from "../../../components/ShareDialogs";
// import { signup, signupResetState } from "./SignUpViewModel";
import { useDispatch, useSelector } from "react-redux";
import { AlertToast, toasito } from "../../../../app/utils/Extensions";
import StyledDropDown from "../../../components/StyledDropDown";
import { getAllLanguagesModel, signup } from "./SignUpViewModel";
import { useIsFocused } from "@react-navigation/native";
import PhotoUploadDialog from "../../../components/PhotoUploadDialog";
import { checkCameraPermission } from "../../../../app/utils/AppPermission";
import ImagePicker from "react-native-image-crop-picker";
import {
  openSettings,
  PERMISSIONS,
  RESULTS,
  request,
} from "react-native-permissions";
import { allLanguages } from "../../../../app/redux/slice";

const SignUpScreen: React.FC<Props> = (props) => {
  var stateArr: {value: string; label: string}[] = [];
    const [fisrtName, setFirstName] = useState("");
    const gender=[ { label: 'Male', value: 'Male' },
    { label: 'Female', value: 'Female' },]
    const [password, setPassword] = useState("");
    const [languages, setLanguages] = useState();
    const [city, setCity] = useState("");
    const [state, setState] = useState("");
    const [email, setEmail] = useState("");
    const [age, setAge] = useState("");
    const [validationError, setValidationError] = useState();
    const [validationError1, setValidationError1] = useState();
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState(null);
    const [value2, setValue2] = useState(null);
    const [items, setItems] = useState(stateArr);
    const isFocused =useIsFocused()
    const [modal2, setModal2] = React.useState(false);
    const [modal3, setModal3] = React.useState(false);
    const [image, setImage] = React.useState();
    const [loader, setLoader] = React.useState();

    const dispatch=useDispatch()

    const stateListFunction = array => {
      array?.map((val: {id: string; name: string}) => {
        stateArr.push({
          value: val.id,
          label: val.name,
        });
      });
      return stateArr;
    };
    useEffect(() => {
     
      getAllLanguagesModel({setLanguages: setLanguages}).then(() => {
        console.log("Languages:", languages);
        
        const stateData = stateListFunction(languages);
        console.log("statedata:", stateData);
        dispatch(allLanguages(stateData));
        setItems(stateData); // Update items2 with state data
      });
    }, []);


    const SettingAlert = ({ type }: any) => {
      Alert.alert(
        "Seeible",
        `User did not grant ${type} permission. You Can Enable it in Settings`,
        [
          { text: "Cancel" },
          { text: "Open Settings", onPress: () => openSettings() },
        ]
      );
    };
  
    const uploadGallery = async () => {
      try {
        if (Platform.OS === "android") {
          const granted = await request(
            PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE
          );
          granted !== "granted" && SettingAlert({ type: "Gallery" });
  
          if (granted === "granted") {
            ImagePicker.openPicker({
              width: 300,
              height: 400,
              cropping: true,
              cropperCircleOverlay: true,
            }).then((image: { path: any }) => {
              setImage(image.path);
            });
          }
          setModal2(false);
        } else {
          const granted = await request(PERMISSIONS.IOS.PHOTO_LIBRARY_ADD_ONLY);
          if (granted) {
            const ref = await ImagePicker.openPicker({
              width: 300,
              height: 400,
              cropping: true,
              cropperCircleOverlay: true,
            });
            setImage(ref.path);
          }
          setModal2(false);
        }
      } catch (er: any) {
        setModal2(false);
        er.message === "User did not grant library permission."
          ? Alert.alert(
              "Seeible",
              er.message + " " + "You Can Enable it in Settings",
              [
                { text: "Cancel" },
                { text: "Open Settings", onPress: () => openSettings() },
              ]
            )
          : er.message != "User did not grant library permission." ||
            (er.message !== "User cancelled image selection" &&
              AlertToast(er.message));
      }
    };
    const useCamera = async () => {
      try {
        if (Platform.OS === "android") {
          const granted = await checkCameraPermission();
          if (granted) {
            ImagePicker.openCamera({
              width: 300,
              height: 400,
              cropping: true,
              cropperCircleOverlay: true,
            }).then((image) => {
              setImage(image.path);
            });
          }
          setModal2(false);
        } else {
          const res = await request(PERMISSIONS.IOS.CAMERA);
          res === "blocked" && SettingAlert({ type: "Camera" });
          const ref = await ImagePicker.openCamera({
            width: 300,
            height: 400,
            cropping: true,
            cropperCircleOverlay: true,
          });
          setImage(ref.path);
          setModal2(false);
          // SettingAlert({ type: "Camera" });
          // res === "blocked" && SettingAlert({ type: "Camera" });
        }
      } catch (er: any) {
        er.message === "User did not grant camera permission."
          ? Alert.alert(
              "BushelPro",
              er.message + " " + "You Can Enable it in Settings",
              [
                { text: "Cancel" },
                { text: "Open Settings", onPress: () => openSettings() },
              ]
            )
          : er.message !== "User cancelled image selection" ||
            (er.message !== "User did not grant camera permission." &&
              AlertToast(er.message));
        // setUploadOptDialog(!uploadOptDialog)
      }
    };
    

    return (
          <SafeAreaView style={styles.container}>
            <View style={[styles.imageBgStyle]}>
              <ImageBackground
                style={[styles.imageBgStyle, { alignItems: "center", zIndex: 1 }]}
                source={Images.IcLoginBg}
              >
                <Image style={styles.logoStyle} source={Images.IcSplash} />
              </ImageBackground>
              <View style={styles.modalView}>
              <View
            style={{
              width: 200,
              height: 150,
              position: "absolute",

              justifyContent: "center",
              alignItems: "center",
              left: WIDTH / 5.2,
              bottom: HEIGHT / 1.68,
              zIndex: 100
            }}
          >
            <ImageBackground
              source={
                image === null
                  ? Images.IcContact
                  : Images.IcContact
              }
              style={styles.imageStyle}
            >
              <TouchableOpacity
                onPress={() => setModal2(!modal2)}
                style={{
                  justifyContent: "flex-end",
                  alignItems: "flex-end",
                  height: HEIGHT / 9,
                  width: WIDTH / 4.5,
                }}
              >
                <Image style={styles.icons} source={Images.IcImage} />
              </TouchableOpacity>
            </ImageBackground>
          </View>
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  contentContainerStyle={{ marginTop: 25 }}
                >
                  <View style={{ flex: 1,marginTop: 50 }}>
                    <StyledInput
                      containerStyle={{ height: HEIGHT / 15 }}
                      headerText="Name"
                      placeholderText="Enter name here"
                      secureTextEntry={false}
                      value={fisrtName}
                      onChange={setFirstName}
                      // error={{status:true,message:"something went wrong"}}
                      textStyle={{
                        color: Colors.black,
                        fontFamily: Fonts.Medium,
                        fontSize: Fonts.large_font,
                      }}
                      leftIcon={<Image style={styles.icons} source={Images.IcUser} />}
                    />
                    <Spacer margin={"4%"} />
                    <StyledInput
                      containerStyle={{ height: HEIGHT / 15 }}
                      // value={Email} // headerText="Email" // containerStyle={{paddingHorizontal:10}}     //   clearError={() => setErrorEmail(errorInitialState)} //   onChange={setEmail}
                      // error={{status:true,message:"something went wrong"}}
                      headerText="Email"
                      placeholderText="name@domain.com"
                      secureTextEntry={false}
                      value={email}
                      onChange={(val) => {
                        if (
                          /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val) &&
                          val !== ""
                        ) {
                          setEmail(val);
      
                          setValidationError(false);
                        } else {
                          setEmail(val);
      
                          setValidationError(true);
                        }
                      }}
                      type="email-address"
                      textStyle={{
                        color: Colors.black,
                        fontFamily: Fonts.Medium,
                        fontSize: Fonts.large_font,
                      }}
                      leftIcon={
                        <Image style={styles.icons} source={Images.IcEmail} />
                      }
                    />
                    {validationError ? (
                      <StyledText
                        text={"Invalid Email*"}
                        style={{
                          margin: 5,
      
                          color: "red",
      
                          fontSize: 13,
                        }}
                      />
                    ) : null}
                     <Spacer margin={"4%"} />
                    <StyledInput
                      containerStyle={{ height: HEIGHT / 15 }}
                      headerText="Age"
                      placeholderText="Enter Age"
                      secureTextEntry={false}
                      value={age}
                      onChange={setAge}
                      // error={{status:true,message:"something went wrong"}}
                      textStyle={{
                        color: Colors.black,
                        fontFamily: Fonts.Medium,
                        fontSize: Fonts.large_font,
                      }}
                      leftIcon={
                        <Image style={styles.icons} source={Images.IcUser} />
                      }
                    />
                    <Spacer margin={"4%"} />
                    <View
          style={{
            gap:12,
            zIndex: 20,
            // height: open ? 250 : null,
          }}
        >
          <StyledText text="Genger" extraStyle={{
                        color: Colors.black,
                        fontFamily: Fonts.Medium,
                        fontSize: Fonts.large_font,
                      }}
           />
                    <Dropdown
          style={styles.dropdown}
          containerStyle={styles.shadow}
          data={gender}
         
          selectedTextStyle={styles.selectedTextStyle}
          labelField="label"
          valueField="value"
          label="Dropdown"
          placeholder="select gender"
          value={value2}
          placeholderStyle={{
            color: '#C0C0C0',
            marginLeft: 20,
          }}
          // onFocus={() => setOpenModal(false)}
          onChange={item => {
            setValue2(item.value);
            // setIsFocus2(false);
          }}
        />
          </View>
                    <Spacer margin={"4%"} />
                    <StyledInput
                      containerStyle={{ height: HEIGHT / 15 }}
                      headerText="City"
                      placeholderText="Enter City"
                      secureTextEntry={false}
                      value={city}
                      onChange={setCity}
                      // error={{status:true,message:"something went wrong"}}
                      textStyle={{
                        color: Colors.black,
                        fontFamily: Fonts.Medium,
                        fontSize: Fonts.large_font,
                      }}
                      leftIcon={
                        <Image style={styles.icons} source={Images.IcMapPin} />
                      }
                    />
                    <Spacer margin={"4%"} />
                    <StyledInput
                      containerStyle={{ height: HEIGHT / 15 }}
                      headerText="Country"
                      placeholderText="Enter Country"
                      secureTextEntry={false}
                      value={state}
                      onChange={setState}
                      // error={{status:true,message:"something went wrong"}}
                      textStyle={{
                        color: Colors.black,
                        fontFamily: Fonts.Medium,
                        fontSize: Fonts.large_font,
                      }}
                      leftIcon={<Image style={styles.icons} source={Images.IcHome} />}
                    />
                    <Spacer margin={"4%"} />
                    <View
          style={{
            gap:12,
            zIndex: 20,
            // height: open ? 250 : null,
          }}
        >
          <StyledText text="Select Language" extraStyle={{
                        color: Colors.black,
                        fontFamily: Fonts.Medium,
                        fontSize: Fonts.large_font,
                      }}
           />
                    <Dropdown
          style={styles.dropdown}
          containerStyle={styles.shadow}
          data={stateListFunction(languages)}
          search
          searchPlaceholder="Search"
          selectedTextStyle={styles.selectedTextStyle}
          labelField="label"
          valueField="value"
          label="Dropdown"
          placeholder="Select Language"
          value={value}
          placeholderStyle={{
            color: '#C0C0C0',
            marginLeft: 20,
          }}
          // onFocus={() => setOpenModal(false)}
          onChange={item => {
            setValue(item.value);
            // setIsFocus2(false);
          }}
        />
          </View>
                    <Spacer margin={"4%"} />
                    <StyledInput
  containerStyle={{ height: HEIGHT / 15 }}
  headerText="Password"
  placeholderText="********"
  secureTextEntry={true}
  value={password}
  onChange={(val) => {
    if (
      /^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^a-zA-Z\d\s:])(.{8,16})$/.test(val) &&
      val !== ""
    ) {
      setPassword(val);
      setValidationError1(false);
    } else {
      setPassword(val);
      setValidationError1(true);
    }
  }}
  textStyle={{
    color: Colors.black,
    fontFamily: Fonts.Medium,
    fontSize: Fonts.large_font,
  }}
  leftIcon={<Image style={styles.icons} source={Images.IcLock} />}
  rightIcon={<Image style={styles.icons} source={Images.IcEyesOff} />}
/>
                     {validationError1 ? (
                      <StyledText
                        text={"New Password must contain at least one Uppercase letter, one Lowercase letter, one Number, and one Special character"}
                        style={{
                          margin: 5,
      
                          color: "red",
      
                          fontSize: 13,
                        }}
                      />
                    ) : null}
                    
                    {/* <View style={styles.checkBoxContainer}>
                      <View style={styles.innerCheckBox}>
                        {Platform.OS === "android" ? (
                          <CheckBox
                            disabled={false}
                            value={rememberMe}
                            tintColor={Colors.green}
                            onCheckColor={Colors.green}
                            onTintColor={Colors.green}
                            boxType={"square"}
                            onValueChange={(newValue) => setRememberMe(newValue)}
                            tintColors={{
                              true: Colors.green,
                              false: Colors.green,
                            }}
                          />
                        ) : (
                          <MyCheckBox value={rememberMe} onChange={setRememberMe} />
                        )}
                        <View
                          style={{
                            flexWrap: "wrap",
                            flexDirection: "row",
                            width: "90%",
                            marginVertical: 5,
                          }}
                        >
                          <StyledText
                            text="By clicking this you accept our "
                            extraStyle={styles.signup3}
                          />
      
                          <StyledText
                            text=" privacy policy"
                            onPress={() => setModal(!modal)}
                            extraStyle={styles.signup4}
                          />
                          <StyledText text=" and" extraStyle={styles.signup3} />
                          <StyledText
                            text=" terms & conditions"
                            onPress={() => setModal(!modal)}
                            extraStyle={styles.signup4}
                          />
                        </View> */}
                      {/* </View> */}
                    </View>
                    <View
                      style={{ flex: 1, alignItems: "center", marginVertical: 5 }}
                    >
                      <StyledButton
                        title="SIGN UP"
                        btnContStyle={{ marginVertical: 25 }}
                         isLoading={loader}
                        onPress={() => {
                         
                            signup({
                              name: fisrtName,
                              age: age,
                              email: email,
                              city: city,
                              country: state,
                              password: password,
                              gender: value2,
                              languageId: value,
                             image: image,
                              navigation: navigate,
                              setLoader: setLoader,
                              setmodal:setModal3
                            })
                         
                        }}
                      />
                      <Pressable
                        style={styles.bottomContainer}
                        onPress={() => navigate("SignIn")}
                      >
                        <StyledText
                          text="Already have an account?"
                          extraStyle={styles.signup1}
                        />
                        <StyledText text=" Sign In" extraStyle={styles.signup2} />
                      </Pressable>
                    </View>
                  {/* </View> */}
                </ScrollView>
              </View>
            </View>
            <PhotoUploadDialog
              visible={modal2}
              onClose={() => setModal2(!modal2)}
              onBtn1Press={() => {
                setModal2(!modal2);
                uploadGallery();
                //navigate("PaymentMethod", { title: "Payment Method" });
              }}
              onBtn2Press={() => {
                setModal2(!modal2);
                useCamera();
                //navigate("PaymentMethod", { title: "Payment Method" });
              }}
              onBtn3Press={() => {
                setModal2(!modal2);

                //navigate("PaymentMethod", { title: "Payment Method" });
              }}
              popup
              btn1="Gallery"
              btn2="Camera"
              btn3="Cancel"
            />


<Dialogs
              visible={modal3}
              onClose={() => setModal3(!modal3)}
              onBtn2Press={() => {
                setModal3(!modal3);
                navigateClear("SignIn");
              }}
              checkIcon
              popup
              title="VERIFY ACCOUNT!"
              btn2="Ok"
              description={"A 4-digit code has been to your email"}
            />
            {/* <ShareDialogs
              visible={modal}
              onClose={() => setModal(!modal)}
              termsPrivacy
              title="Terms & Conditions"
              description={
                "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ,hdskjfhdsjkafhadjksfhjkdsahf dsfsfdssdf dsfdsfadsf dsfadsfsdaf sdafadsfadsf sdfdsafdsaf dsfadsfadsf dsfadsfsadf dsfasdfasdf sdfsdafsadf sdfadsfdsaf sdfsdafads sdafsadfdsaf sdafadsfasdf sdafadsfdsaf asdfadsfdsaf sdafasdfdsaf "
              }
            /> */}
          </SafeAreaView>
        );
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  imageBgStyle: { width: "100%", height: 360, alignItems: "center" },
  logoStyle: {
    top: 24,
    width: 144,
    height: 165,
  },
  
  icons: { width: 20, height: 20, resizeMode: "contain" },
  loginFormStyle: {
    height: 22,
    backgroundColor: "red",

    paddingHorizontal: 20,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
    position: "absolute",
    bottom: 0,
  },
  modalView: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    height: HEIGHT / 1.4,
    width: WIDTH / 1.1,
    backgroundColor: "white",
    position: "absolute",
    top: 210,
    zIndex: 999,
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  container1: {
    width: WIDTH / 2,
    padding: 25,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  button1: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    backgroundColor: "#2AC062",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  closeButton: {
    display: "flex",
    height: 60,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FF3974",
    shadowColor: "#2AC062",
    shadowOpacity: 0.5,
    shadowOffset: {
      height: 10,
      width: 0,
    },
    shadowRadius: 25,
  },
  imageStyle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    marginBottom: 12,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 22,
  },
  image: {
    marginTop: 150,
    marginBottom: 10,
    width: "100%",
    height: 350,
  },
  text: {
    fontSize: 24,
    marginBottom: 30,
    padding: 40,
  },
  checkBoxContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginTop: 10,
  },
  innerCheckBox: { flexDirection: "row" },
  rememberMe: { color: Colors.black, fontFamily: Fonts.Medium },
  forgot: {
    color: Colors.black,
    textDecorationLine: "underline",
    fontFamily: Fonts.Medium,
  },
  signup1: {
    color: Colors.grey,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
  },
  signup2: {
    color: Colors.green,
    fontSize: Fonts.xmedium_font,
    alignSelf: "center",
    fontFamily: Fonts.SemiBold,
  },
  bottomContainer: {
    marginTop: 10,
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 80,
  },
  signup3: {
    color: Colors.Seventy,
    fontSize: Fonts.medium_font - 1,
    fontFamily: Fonts.Regular,
  },
  signup4: {
    color: Colors.green,
    fontSize: Fonts.medium_font - 1,
    fontFamily: Fonts.Regular,
  },
  dropdown: {
    height: 48,
    borderColor: 'gray',
    backgroundColor: 'white',
    borderWidth: 1,
    borderRadius: 5,
    // paddingHorizontal: 40,

    // marginTop: 20,
    // width: "100%",
  },
  selectedTextStyle: {
    color: 'black',
    marginLeft: 20,
  },
  shadow: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },}
});
export default SignUpScreen;