import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { StyledText } from "./StyledText";
import { HEIGHT, WIDTH } from "../../app/utils/AppConstants";
import Fonts from "../../app/utils/Fonts";
import Colors from "../../app/utils/Colors";

type Props = {
  leftText: string;
  rightText?: string;
};

const ShowDetails: React.FC<Props> = ({ leftText, rightText }) => {
  return (
    <>
      <View
        style={
          leftText == "Notes:"
            ? [styles.container, { height: HEIGHT / 9 }]
            : styles.container
        }
      >
        <View style={styles.textContainer}>
          <StyledText text={leftText} extraStyle={styles.text} />
        </View>
        {leftText == "Notes:" ? (
          <ScrollView
            horizontal={false}
            contentContainerStyle={[
              styles.textContainer,
              {
                width: "100%",
                alignItems: "flex-start",
                marginLeft: 25,
              },
            ]}
            nestedScrollEnabled={true}
          >
            <Text style={leftText === "Notes:" ? styles.text2 : styles.text1}>
              {rightText}
            </Text>
          </ScrollView>
        ) : rightText === "" ? null : (
          <View style={[styles.textContainer]}>
            <Text style={leftText === "Notes:" ? styles.text2 : styles.text1}>
              {rightText}
            </Text>
          </View>
        )}
      </View>
      {leftText === "Notes:" ? null : <View style={styles.border} />}
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: HEIGHT / 13,
    paddingHorizontal: 20,
  },
  container1: {
    backgroundColor: "red",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: HEIGHT / 9,
    width: WIDTH,
    paddingHorizontal: 10,
  },
  textContainer: {
    alignItems: "center",
  },
  text: {
    fontSize: Fonts.xlarge_font,
    fontFamily: Fonts.Medium,
    color: Colors.black,
  },
  text1: {
    fontSize: Fonts.xlarge_font - 1,
    fontFamily: Fonts.Regular,
    color: Colors.black,
  },
  text2: {
    fontSize: Fonts.xlarge_font - 3,
    fontFamily: Fonts.Regular,
    color: Colors.black,
    width: WIDTH / 1.4,
    marginRight: 5,
  },

  border: {
    width: "100%",
    height: 1,
    backgroundColor: "#ccc",
  },
});

export default ShowDetails;
