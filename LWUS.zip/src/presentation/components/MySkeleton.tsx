import { Skeleton } from "@rneui/themed";
import { StyleSheet } from "react-native";
import Colors from "../../app/utils/Colors";

export interface SkeletonType {
  width?: string | number;
  height?: any;
  style?: any;
}

export const MySkeleton: React.FC<SkeletonType> = ({
  width,
  height,
  style,
}) => (
  <Skeleton
    skeletonStyle={{ backgroundColor: "#dddddd" }}
    width={width ? width : ("50%" as any)}
    height={height ? height : 40}
    style={[styles.skeleton, style]}
  />
);

const styles = StyleSheet.create({
  skeleton: {
    alignSelf: "flex-end",
    marginTop: 30,
    backgroundColor: Colors.SenderColor,
    borderRadius: 10,
  },
});
