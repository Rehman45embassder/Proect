import React, { useState, useCallback, CSSProperties } from "react";
import {
  View,
  TouchableOpacity,
  Image,
  StyleSheet,
  ViewStyle,
  Pressable,
} from "react-native";
import { Input } from "@rneui/themed";
import Colors from "../../app/utils/Colors";
import Images from "../../app/utils/Images";
import { StyledText } from "./StyledText";
import Fonts from "../../app/utils/Fonts";

type Props = {
  value?: any;
  placeholderText?: string;
  containerStyle?: CSSProperties | ViewStyle;
  mainContainerStyle?: CSSProperties | ViewStyle;
  secureTextEntry?: boolean;
  placeholderTextColor?: string;
  headerText?: string;
  textStyle?: any;
  inputTextStyle?: ViewStyle | CSSProperties | any;
  leftIcon?: HTMLImageElement;
  rightIcon?: HTMLImageElement;
  edit?: boolean;
  multiline?: boolean;
  type?: any;
  maxLength?: number;
  format?: string;
  onPress?: any;
  phoneNumber?: boolean;
  error?: {
    status?: any;
    message?: any;
  };
  clearError?: any;
  onChange?: any;
  Height?: number;
};

const StyledInput: React.FC<Props> = React.forwardRef((props, ref) => {
  const [Focused, setFocus] = useState(false);
  const [touched, setTouched] = useState(false);
  const [showPass, setShowPass] = React.useState(props?.secureTextEntry);
  // const [Error, setError]= useState((props?.error == null)?{ status: false, message: "" }:props?.error);

  if (!touched) {
    setTouched(true);
  }

  //   if (props.clearTextOnFocus && Focused && text.length) setText("")
  //   const updateText = (text) => {
  //     setText(text);
  //     props.onChangeText && props.onChangeText(text);
  //   }

  const onChange = (text: string) => {
    switch (props?.format) {
      case "phoneNumber": {
        var cleaned = ("" + text).replace(/\D/g, "");
        var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
        if (match) {
          props?.onChange("(" + match[1] + ") " + match[2] + "-" + match[3]);
        } else {
          props?.onChange(text);
        }
        break;
      }
      case "card": {
        let formattedText = text.split(" ").join("");
        if (formattedText.length > 0) {
          props?.onChange(
            formattedText.match(new RegExp(".{1,4}", "g"))?.join(" ")
          );
        } else {
          props?.onChange(text);
        }
        break;
      }
    }
  };

  return (
    <View
      style={{
        paddingBottom:
          props?.error?.message?.slice(0, 15) === "Password should" ? 18 : 0,
        height: props.Height ? props.Height : 83,
      }}
    >
      {props?.headerText && (
        <StyledText
          text={props?.headerText}
          extraStyle={{
            fontSize: 14,
            fontWeight: "normal",
            ...props?.textStyle,
          }}
        />
      )}
      <TouchableOpacity
        activeOpacity={1}
        onPress={props?.onPress}
        disabled={!props?.onPress}
      >
        <Input
          multiline={props?.multiline}
          value={props?.value}
          editable={props?.edit}
          inputContainerStyle={[
            styles.mainContainer,
            props.containerStyle as any,
          ]}
          placeholder={props?.placeholderText}
          containerStyle={props.mainContainerStyle as any}
          placeholderTextColor={
            props.placeholderTextColor
              ? props.placeholderTextColor
              : Colors.grey
          }
          secureTextEntry={showPass}
          onFocus={() =>
            props?.error?.status === true ? props?.clearError() : ""
          }
          leftIcon={props.leftIcon}
          rightIcon={
            props?.error?.status === true ? (
              <Image source={Images.Error} style={{ width: 25, height: 25 }} />
            ) : props?.secureTextEntry === true ? (
              <Pressable onPress={() => setShowPass(!showPass)}>
                {props.rightIcon}
              </Pressable>
            ) : (
              props.rightIcon
            )
          }
          keyboardType={props?.type}
          returnKeyType="done"
          inputStyle={[
            props.inputTextStyle,
            { fontSize: Fonts.xmedium_font - 2, fontFamily: Fonts.Regular },
          ]}
          maxLength={props?.maxLength}
          errorMessage={props?.error?.message}
          errorStyle={{
            alignSelf: "flex-end",
            color: "#FF7560",
            fontSize: 13,
            right: 10,
          }}
          onChangeText={props?.format != null ? onChange : props?.onChange}
        />
      </TouchableOpacity>
    </View>
  );
});

export default StyledInput;

const styles = StyleSheet.create({
  mainContainer: {
    height: 60,

    paddingHorizontal: 15,

    paddingBottom: 0,
    marginHorizontal: -10,
  },
});
