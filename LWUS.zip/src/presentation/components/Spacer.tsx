import React, { useState, useCallback, CSSProperties } from "react";
import {
    View,
  } from 'react-native';

type Props = {
  margin ?: any
}

export const Spacer : React.FC<Props> = (props) => {
  return (
    <View style={{margin:props?.margin}}/>
  )
}
