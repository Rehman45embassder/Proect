import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import Colors from "../../app/utils/Colors";
import { StyledText } from "./StyledText";
import LinearGradient from "react-native-linear-gradient";
import Fonts from "../../app/utils/Fonts";
import { HEIGHT, WIDTH } from "../../app/utils/AppConstants";

type Props = {
  year: string;
  text: string;
  count: string;

  onPress?: () => void;
};

const Count: React.FC<Props> = ({
  year,
  text,
  count,

  onPress,
}) => {
  return (
    <Pressable style={styles.main} onPress={onPress}>
      <View style={styles.view}>
        <StyledText text={year} style={styles.type} />

        <View>
          <StyledText text={text} style={styles.days1} />
          <StyledText text={count} style={styles.days} />
        </View>
      </View>
    </Pressable>
  );
};

export default Count;
const wid = 175;
const styles = StyleSheet.create({
  type: { fontFamily: Fonts.SemiBold, fontSize: 22 },
  days: {
    width: WIDTH / 3,
    fontFamily: Fonts.Medium,
    fontSize: 18,
    textAlign: "center",
  },
  days1: {
    width: WIDTH / 3,
    fontFamily: Fonts.Medium,
    fontSize: 18,
  },
  view: {
    width: WIDTH / 1.1,
    flexDirection: "row",
    flex: 1,
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
  },
  item: { color: Colors.black, fontFamily: Fonts.Regular, fontSize: 16 },

  // main:{width:wid,height:185,backgroundColor:Colors.white,borderRadius:18,alignItems:'center',padding:6,shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,paddingVertical:8,marginBottom:15},
  main: {
    flex: 1,
    width: WIDTH / 1.1,
    height: HEIGHT / 9,
    backgroundColor: Colors.green,

    borderRadius: 15,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 5,
    paddingVertical: 4,
    marginBottom: 10,
  },
});
