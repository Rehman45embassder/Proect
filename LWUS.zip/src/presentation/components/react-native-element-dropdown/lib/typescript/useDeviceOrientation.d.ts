export declare function useDeviceOrientation(): "PORTRAIT" | "LANDSCAPE";
