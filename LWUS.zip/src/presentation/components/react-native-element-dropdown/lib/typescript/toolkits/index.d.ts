import type { IUseDetectDevice } from './model';
declare const useDetectDevice: IUseDetectDevice;
export { useDetectDevice };
