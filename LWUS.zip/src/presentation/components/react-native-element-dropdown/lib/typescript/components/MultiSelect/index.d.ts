import React from 'react';
import type { MultiSelectProps } from './model';
declare const MultiSelectComponent: React.ForwardRefExoticComponent<MultiSelectProps & React.RefAttributes<any>>;
export default MultiSelectComponent;
