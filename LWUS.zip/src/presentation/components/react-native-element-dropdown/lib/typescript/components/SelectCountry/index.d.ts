import React from 'react';
import type { SelectCountryProps } from './model';
declare const SelectCountryConponent: React.ForwardRefExoticComponent<SelectCountryProps & React.RefAttributes<any>>;
export default SelectCountryConponent;
