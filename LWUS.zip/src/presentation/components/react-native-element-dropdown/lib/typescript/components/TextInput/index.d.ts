import type { CTextInput } from './model';
declare const TextInputComponent: CTextInput;
export default TextInputComponent;
