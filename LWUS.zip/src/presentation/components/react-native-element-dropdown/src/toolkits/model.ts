export interface IUseDetectDevice {
  isAndroid: boolean;
  isIOS: boolean;
  isTablet: boolean;
}
