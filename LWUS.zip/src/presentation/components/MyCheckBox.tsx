import React, { useState } from "react";
import { StyleSheet, Animated } from "react-native";
import Colors from "../../app/utils/Colors";
import { Icon } from "@rneui/base";
import { Pressable } from "react-native";
import { HEIGHT } from "../../app/utils/AppConstants";

type Props = {
  navigation?: any;
  value: boolean;
  onChange: any;
};

const MyCheckBox: React.FC<Props> = ({ value, onChange }: Props) => {
  const opacity = new Animated.Value(value ? 0 : 1);
  const [pressed, setPressed] = useState(false);
  React.useEffect(() => {
    Animated.timing(opacity, {
      toValue: value ? 1 : 0,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, [value]);

  return (
    <Pressable
      hitSlop={{ top: 15, bottom: 15, left: 15, right: 15 }}
      onPress={() => {
        onChange(!value);
        setPressed(!pressed);
      }}
      style={[
        styles.box,
        { backgroundColor: pressed ? Colors.green : "transparent" },
      ]}
    >
      <Animated.View style={{ opacity: opacity }}>
        <Icon type="feather" name="check" color={Colors.white} size={18} />
      </Animated.View>
    </Pressable>
  );
};

export default MyCheckBox;

const styles = StyleSheet.create({
  box: {
    marginTop: HEIGHT / 135,
    width: 21,
    height: 20,
    borderColor: Colors.green,
    borderWidth: 1.8,
    borderRadius: 2,
    marginRight: 4,
    justifyContent: "center",
    alignItems: "center",
  },
});
