import React, { CSSProperties } from "react";
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ViewStyle,
} from "react-native";
import MyView from "../components/MyView";
import Colors from "../../app/utils/Colors";
import Fonts from "../../app/utils/Fonts";
import { HEIGHT } from "../../app/utils/AppConstants";

type Props = {
  navigation?: any;
  title: string;
  textStyle?: CSSProperties | ViewStyle;
  btnContStyle?: CSSProperties | ViewStyle;
  isLoading?: boolean;
  disabled?: boolean;
  onPress?: () => void;
  bgColor?: boolean;
  showShadow?: boolean;
};

const StyledButton: React.FC<Props> = ({
  navigation,
  title,
  textStyle,
  btnContStyle,
  isLoading,
  disabled,
  onPress,
  bgColor,
  showShadow,
}) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      style={[
        styles.btnStyle,
        btnContStyle as ViewStyle,
        {
          backgroundColor: bgColor
            ? isLoading
              ? Colors.green
              : "transparent"
            : Colors.green,
        },
        showShadow && {
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.23,
          shadowRadius: 2.62,
          elevation: 4,
        },
      ]}
    >
      {isLoading ? (
        <ActivityIndicator size="small" color={Colors.white} />
      ) : (
        <Text style={[styles.textSty, textStyle as ViewStyle]}>{title}</Text>
      )}
    </TouchableOpacity>
  );
};

export default StyledButton;

const styles = StyleSheet.create({
  btnStyle: {
    backgroundColor: Colors.green,
    height: HEIGHT / 15.5,
    width: 250,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#fff",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.27,
    shadowRadius: 4.65,
  },
  textSty: { fontFamily: Fonts.Medium, color: Colors.white, fontSize: 17 },
});
