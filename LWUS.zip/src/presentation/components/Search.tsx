import React from 'react';
import {View, Image, TextInput, StyleSheet, Text} from 'react-native';
import {HEIGHT, WIDTH} from '../../app/utils/AppConstants';
import Fonts from '../../app/utils/Fonts';
import {Spacer} from './Spacer';

type Props = {
  image: any;

  placeHolder?: string;
};

const Search: React.FC<Props> = ({
  image,

  placeHolder,
}) => {
  return (
    <View style={styles.container}>
      <Image source={image} style={styles.image} />
      <View>
        <Spacer margin={'5%'} />
        <TextInput style={styles.textInput} placeholder={placeHolder} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 10,
    width: WIDTH / 1.3,
    height: HEIGHT / 14.8,
    margin: 5,
  },
  image: {
    width: 22,
    height: 22,
    marginHorizontal: 5,
    marginLeft: 20,
  },
  textInput: {
    marginBottom: 0,
    fontFamily: Fonts.Regular,
    fontSize: Fonts.large_font,
    color: '#000',
  },
});

export default Search;
