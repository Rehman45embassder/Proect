import React from "react";
import {
  Image,
  Modal,
  Platform,
  StatusBar,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import Colors from "../../app/utils/Colors";
import { HEIGHT, WIDTH } from "../../app/utils/AppConstants";
import { StyledText } from "./StyledText";
import Fonts from "../../app/utils/Fonts";
import Images from "../../app/utils/Images";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import StyledButton from "./StyledButton";
import { Spacer } from "./Spacer";
import CheckBox from "@react-native-community/checkbox";
import MyCheckBox from "./MyCheckBox";
type Props = {
  navigation?: any;
  visible?: boolean;
  termsPrivacy?: boolean;
  popup?: boolean;
  popup2?: boolean;
  popup3?: boolean;
  checkIcon?: boolean;
  Icon?: any;
  title?: any;
  description?: string;
  onClose?: () => void;
  btn1?: string;
  onBtn1Press?: () => void;
  btn2?: string;
  onBtn2Press?: () => void;
};

const Dialogs: React.FC<Props> = ({
  visible,
  termsPrivacy,
  title,
  description,
  onClose,
  btn1,
  onBtn1Press,
  btn2,
  onBtn2Press,
  popup,
  popup2,
  popup3,
  checkIcon,
  Icon,
}) => {
  const [rememberMe, setRememberMe] = React.useState(false);
  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}
    >
      <View style={styles.mainContainer}>
        {termsPrivacy && (
          <View style={styles.container1}>
            <TouchableOpacity
              hitSlop={styles.hitSlop}
              onPress={onClose}
              style={styles.crossView}
            >
              <Image source={Images.IcCross} style={styles.crossIcon} />
            </TouchableOpacity>
            <View style={styles.box}>
              <StyledText text={title} extraStyle={styles.title2} />
            </View>
            <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
              <StyledText text={description} extraStyle={styles.text2} />
            </KeyboardAwareScrollView>
          </View>
        )}
        {popup && (
          <View style={styles.container2}>
            <View
              style={{
                backgroundColor: Colors.lightGreen1,
                borderTopRightRadius: 90,
                borderBottomLeftRadius: 90,
                borderTopLeftRadius: 12,
                paddingHorizontal: 10,
                borderBottomRightRadius: 12,

                height: 240,
              }}
            >
              {checkIcon && (
                <View
                  style={{
                    backgroundColor: Colors.green,
                    width: 90,
                    height: 90,
                    borderRadius: 45,
                    position: "absolute",
                    alignItems: "center",
                    justifyContent: "center",
                    top: -HEIGHT / 25,
                    left: WIDTH / 2.7,
                  }}
                >
                  <Image
                    style={styles.crossIcon}
                    source={Icon ? Icon : Images.IcTick}
                  />
                </View>
              )}
              {/* <TouchableOpacity hitSlop={{top:25, right:25,left:25,bottom:25}} onPress={onClose} style={{position:'absolute',right:10,top:15}}><Image source={Images.IcCross} style={styles.crossIcon} /></TouchableOpacity> */}
              <View style={styles.titleView}>
                <Spacer margin={"6%"} />
                <StyledText text={title} extraStyle={styles.title} />
              </View>
              <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
                <StyledText text={description} extraStyle={styles.text} />
              </KeyboardAwareScrollView>
              <View style={styles.buttonView}>
                {btn1 && (
                  <View
                    style={{
                      width: "45%",

                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <StyledButton
                      onPress={onBtn1Press}
                      bgColor
                      title={btn1}
                      btnContStyle={{
                        width: "100%",
                        backgroundColor: Colors.black,
                        fontFamily: Fonts.Medium,
                        position: "absolute",
                        borderWidth: 1,
                        borderColor: Colors.green,
                      }}
                      textStyle={{
                        color: Colors.green,
                      }}
                    />
                  </View>
                )}
                {btn2 && (
                  <View
                    style={{
                      width: "45%",

                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <StyledButton
                      onPress={onBtn2Press}
                      title={btn2}
                      btnContStyle={{
                        width: "100%",
                        fontFamily: Fonts.Medium,
                        position: "absolute",
                      }}
                    />
                  </View>
                )}
              </View>
            </View>
          </View>
        )}
        {popup2 && (
          <View style={styles.container2Popup}>
            <View
              style={{
                backgroundColor: Colors.lightGreen1,
                borderTopRightRadius: 90,
                borderBottomLeftRadius: 90,
                borderTopLeftRadius: 12,
                borderBottomRightRadius: 12,

                height: HEIGHT / 2.3,
              }}
            >
              {checkIcon && (
                <View
                  style={{
                    backgroundColor: Colors.green,
                    width: 90,
                    height: 90,
                    borderRadius: 45,
                    position: "absolute",
                    alignItems: "center",
                    justifyContent: "center",
                    top: -HEIGHT / 25,
                    left: WIDTH / 2.7,
                  }}
                >
                  <Image
                    style={styles.crossIcon}
                    source={Icon ? Icon : Images.IcTick}
                  />
                </View>
              )}
              {/* <TouchableOpacity hitSlop={{top:25, right:25,left:25,bottom:25}} onPress={onClose} style={{position:'absolute',right:10,top:15}}><Image source={Images.IcCross} style={styles.crossIcon} /></TouchableOpacity> */}
              <View style={styles.titleView}>
                <Spacer margin={"6%"} />
                <StyledText text={title} extraStyle={styles.title} />
              </View>
              <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
                <StyledText text={description} extraStyle={styles.text} />
                <View style={styles.checkBoxContainer1}>
                  <View style={styles.innerCheckBox}>
                    {Platform.OS === "android" ? (
                      <CheckBox
                        disabled={false}
                        value={rememberMe}
                        tintColor={Colors.green}
                        onCheckColor={Colors.green}
                        onTintColor={Colors.green}
                        boxType={"square"}
                        onValueChange={(newValue) => setRememberMe(newValue)}
                        tintColors={{
                          true: Colors.green,
                          false: Colors.green,
                        }}
                      />
                    ) : (
                      <MyCheckBox value={rememberMe} onChange={setRememberMe} />
                    )}
                    <StyledText
                      text="Yes, I want to delete my account"
                      extraStyle={styles.rememberMe}
                    />
                  </View>
                </View>
              </KeyboardAwareScrollView>
              <View style={styles.buttonView}>
                {btn1 && (
                  <View
                    style={{
                      width: "45%",

                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <StyledButton
                      onPress={onBtn1Press}
                      bgColor
                      title={btn1}
                      btnContStyle={{
                        width: "100%",
                        backgroundColor: "transparent",
                        fontFamily: Fonts.Medium,
                        position: "absolute",
                        borderWidth: 1,
                        borderColor: Colors.green,
                      }}
                      textStyle={{ color: Colors.Seventy }}
                    />
                  </View>
                )}
                {btn2 && (
                  <View
                    style={{
                      width: "45%",

                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <StyledButton
                      onPress={onBtn2Press}
                      title={btn2}
                      btnContStyle={{
                        width: "100%",
                        fontFamily: Fonts.Medium,
                        position: "absolute",
                      }}
                    />
                  </View>
                )}
              </View>
            </View>
          </View>
        )}
      </View>
    </Modal>
  );
};

export default Dialogs;

const styles = StyleSheet.create({
  checkBoxContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  checkBoxContainer1: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
  },

  innerCheckBox: { flexDirection: "row", alignItems: "center" },
  rememberMe: { color: Colors.black, fontFamily: Fonts.Medium },
  btn: {
    width: "45%",
    fontFamily: Fonts.Medium,
    borderWidth: 1,
    borderColor: Colors.Seventy,
  },
  mainContainer: {
    backgroundColor: "#fff",
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  buttonView: {
    flexDirection: "row",
    marginTop: 30,
    marginBottom: HEIGHT / 400,
    justifyContent: "space-around",
  },
  titleView: { width: "100%", alignItems: "center", justifyContent: "center" },
  text2: {
    color: Colors.txtColor,
    fontSize: Fonts.small_font,
    alignSelf: "center",
  },
  crossView: { position: "absolute", right: 10, top: 15 },
  hitSlop: { top: 30, right: 30, left: 30, bottom: 30 },
  box: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  title2: {
    color: Colors.blackOpacity,
    fontSize: Fonts.xlarge_font,
    fontFamily: Fonts.Medium,
    marginVertical: 15,
  },
  title: {
    color: Colors.blackOpacity,
    fontSize: Fonts.xlarge_font - 1,
    fontFamily: Fonts.SemiBold,
    marginVertical: 22,
    textAlign: "center",
    marginHorizontal: 10,
  },
  text: {
    textAlign: "center",
    color: Colors.grayText,
    fontSize: Fonts.xmedium_font - 3,
    marginHorizontal: 6,
    bottom: 2,
  },
  container1: {
    backgroundColor: Colors.white,
    height: HEIGHT / 1.25,
    width: WIDTH * 0.9,
    borderRadius: 5,
    paddingBottom: 20,
    paddingHorizontal: 15,
  },
  container2: {
    backgroundColor: Colors.LightSteelGreen,
    minHeight: "20%",
    width: "95%",
    borderRadius: 20,
    paddingBottom: 40,
    height: "45%",
    paddingTop: 40,
  },
  container2Popup: {
    backgroundColor: Colors.LightSteelGreen,
    minHeight: "20%",
    width: "95%",
    borderRadius: 20,
    paddingBottom: 40,
    height: "55%",
    paddingTop: 40,
  },
  crossIcon: { width: 25, height: 25, resizeMode: "contain" },
});
