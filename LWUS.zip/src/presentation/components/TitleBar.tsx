import React, { useEffect, useState } from "react";
import {
  Image,
  ImageSourcePropType,
  Platform,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import MyView, { MyStatusBar } from "../components/MyView";
import Colors from "../../app/utils/Colors";
import { StyledText } from "./StyledText";
import Fonts from "../../app/utils/Fonts";
import Images from "../../app/utils/Images";
import { SafeAreaView } from "react-native";
import { HEIGHT, WIDTH } from "../../app/utils/AppConstants";
// import Styles from "../modules/dashboard/notification/Styles";
// import { NotificationCount } from "../modules/dashboard/notification/NotificationViewModel";
import { useIsFocused } from "@react-navigation/native";

type Props = {
  navigation?: any;
  title: string;
  onPressBack?: () => void;
  leftImagePath?: ImageSourcePropType | any;
  onRightImagePath?: ImageSourcePropType | any;
  onPressRightImage?: () => void;
  onRightImage2Path?: ImageSourcePropType | any;
  onPressRightImage2?: () => void;
  textColor?: boolean; // new prop to change the text color
};
const CustomStatusBar = ({ backgroundColor }: any) =>
  Platform.OS === "android" ? (
    <StatusBar backgroundColor={backgroundColor} />
  ) : (
    <MyStatusBar backgroundColor={backgroundColor} barStyle="light-content" />
  );

const TitleBar: React.FC<Props> = ({
  navigation,
  title,
  leftImagePath,
  onPressBack,
  onRightImagePath,
  onRightImage2Path,
  onPressRightImage,
  onPressRightImage2,
  textColor, // new prop to change the text color
}) => {
  const [loader, setLoader] = useState();
  const [count, setCount] = useState();
  const isFocused = useIsFocused();

  // useEffect(() => {
  //   if (isFocused) {
  //     NotificationCount({
  //       setLoader: setLoader,
  //       setCount: setCount,
  //     });
  //   }
  // }, [isFocused]);
  return (
    <>
      {}
      {/* <CustomStatusBar backgroundColor={Colors.darkBlue} /> */}
      <SafeAreaView>
        <View style={styles.main}>
          {onPressBack && (
            <TouchableOpacity
              onPress={onPressBack}
              style={{
                position: "absolute",
                left: WIDTH / 30,
                top: HEIGHT / 55,
              }}
            >
              <Image
                style={{ resizeMode: "contain", width: 27, height: 27 }}
                source={leftImagePath ? leftImagePath : Images.IcBackArrow}
              />
            </TouchableOpacity>
          )}
          <StyledText
            extraStyle={textColor ? styles.title1 : styles.title}
            text={title}
          />
          <View
            style={{ flexDirection: "row", position: "absolute", right: 1 }}
          >
            {onRightImagePath && (
              <TouchableOpacity
                onPress={onPressRightImage}
                hitSlop={styles.hitSlop}
                style={{ marginHorizontal: onRightImage2Path ? 10 : 18 }}
              >
                <View style={styles.notiStyles}>
                  {count != 0 ? (
                    <View
                      style={{
                        width: 20,

                        height: 20,

                        borderRadius: 20,

                        backgroundColor: Colors.green,

                        position: "absolute",

                        top: -10,

                        right: -5,

                      
                      }}
                    >
                      <StyledText
                        text={count}
                        extraStyle={{
                          fontFamily: Fonts.Regular,

                          fontSize: 16,

                          color: Colors.white,
                        }}
                      />
                    </View>
                  ) : null}

                  <View>
                    <Image
                      source={onRightImagePath}
                      style={{
                        width: 23,

                        height: 23,

                        resizeMode: "contain",
                      }}
                    />
                  </View>
                </View>
              </TouchableOpacity>
            )}
            {onRightImage2Path && (
              <TouchableOpacity
                onPress={onPressRightImage2}
                hitSlop={styles.hitSlop}
                style={{ marginHorizontal: onRightImage2Path ? 9 : 15 }}
              >
                <Image source={onRightImage2Path} style={styles.icons} />
              </TouchableOpacity>
            )}
          </View>
        </View>
      </SafeAreaView>
    </>
  );
};

export default TitleBar;

const styles = StyleSheet.create({
  hitSlop: { top: 10, bottom: 10, left: 10, right: 10 },
  main: {
    height: 60,
    width: WIDTH,
    backgroundColor: "transparent",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#0000003B",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 4,
    flexDirection: "row",
  },
  icons: { width: 23.45, height: 29.35, resizeMode: "contain" },
  title: { fontFamily: Fonts.SemiBold, fontSize: Fonts.xlarge_font },
  title1: {
    fontFamily: Fonts.SemiBold,
    fontSize: Fonts.xlarge_font - 2,
    color: Colors.green,
  },
  notiStyles: {
    width: 35,

    height: 35,

    borderRadius: 35,

 
  },
});
