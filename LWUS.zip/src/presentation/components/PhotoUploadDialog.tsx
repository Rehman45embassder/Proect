import React from "react";
import {
  Image,
  Modal,
  Platform,
  StatusBar,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import Colors from "../../app/utils/Colors";
import { HEIGHT, WIDTH } from "../../app/utils/AppConstants";
import { StyledText } from "./StyledText";
import Fonts from "../../app/utils/Fonts";
import Images from "../../app/utils/Images";
// import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import StyledButton from "./StyledButton";
import { Spacer } from "./Spacer";
import CheckBox from "@react-native-community/checkbox";
import MyCheckBox from "./MyCheckBox";
import StyledInput from "./StylesInput";
type Props = {
  navigation?: any;
  visible?: boolean;
  termsPrivacy?: boolean;
  popup?: boolean;
  popup2?: boolean;
  checkIcon?: boolean;
  Icon?: any;
  title?: any;
  description?: string;
  onClose?: () => void;
  btn1?: string;
  onBtn1Press?: () => void;
  btn2?: string;
  onBtn2Press?: () => void;
  btn3?: string;
  onBtn3Press?: () => void;
};

const PhotoUploadDialog: React.FC<Props> = ({
  visible,
  termsPrivacy,
  title,
  description,
  onClose,
  btn1,
  onBtn1Press,
  btn2,
  onBtn2Press,
  btn3,
  onBtn3Press,
  popup,
  popup2,
  checkIcon,
  Icon,
}) => {
  const [rememberMe, setRememberMe] = React.useState(false);
  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}
    >
      <TouchableOpacity onPress={onClose} style={styles.mainContainer}>
        {popup && (
          <View style={styles.container2}>
            {btn1 && (
              <View
                style={{
                  width: WIDTH / 1.5,
                  marginBottom: 8,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <StyledButton
                  onPress={onBtn1Press}
                  title={btn1}
                  btnContStyle={{
                    width: "100%",
                    fontFamily: Fonts.Medium,
                  }}
                />
              </View>
            )}

            {btn2 && (
              <View
                style={{
                  width: WIDTH / 1.5,
                  marginBottom: 8,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <StyledButton
                  onPress={onBtn2Press}
                  title={btn2}
                  btnContStyle={{
                    width: "100%",
                    fontFamily: Fonts.Medium,
                  }}
                />
              </View>
            )}

            {btn3 && (
              <View
                style={{
                  width: WIDTH / 1.5,

                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <StyledButton
                  onPress={onBtn3Press}
                  title={btn3}
                  btnContStyle={{
                    width: "100%",
                    fontFamily: Fonts.Medium,
                  }}
                />
              </View>
            )}
          </View>
        )}
      </TouchableOpacity>
    </Modal>
  );
};

export default PhotoUploadDialog;

const styles = StyleSheet.create({
  checkBoxContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  checkBoxContainer1: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
  },

  innerCheckBox: { flexDirection: "row", alignItems: "center" },
  rememberMe: { color: Colors.black, fontFamily: Fonts.Medium },
  btn: {
    width: "45%",
    fontFamily: Fonts.Medium,
    borderWidth: 1,
    borderColor: Colors.Seventy,
  },
  mainContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",

    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  buttonView: {
    flexDirection: "row",
    marginTop: 30,
    marginBottom: 10,
    justifyContent: "space-around",
  },
  titleView: { width: "100%", alignItems: "center", justifyContent: "center" },
  text2: {
    color: Colors.txtColor,
    fontSize: Fonts.small_font,
    alignSelf: "center",
  },
  crossView: { position: "absolute", right: 10, top: 15 },
  hitSlop: { top: 30, right: 30, left: 30, bottom: 30 },
  box: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  title2: {
    color: Colors.blackOpacity,
    fontSize: Fonts.xlarge_font,
    fontFamily: Fonts.Medium,
    marginVertical: 15,
  },
  title: {
    color: Colors.blackOpacity,
    fontSize: Fonts.xlarge_font - 1,
    fontFamily: Fonts.SemiBold,
    marginTop: 22,
    textAlign: "center",
    marginHorizontal: 10,
  },
  text: {
    textAlign: "center",
    color: Colors.grayText,
    fontSize: Fonts.xmedium_font - 1,
    marginHorizontal: 6,
    bottom: 2,
  },
  container1: {
    backgroundColor: Colors.white,
    height: HEIGHT / 1.25,
    width: WIDTH * 0.9,
    borderRadius: 5,
    paddingBottom: 20,
    paddingHorizontal: 15,
  },
  container2: {
    backgroundColor: Colors.LightSteelGreen,

    width: WIDTH,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 20,
    paddingBottom: 40,
    height: "30%",
    paddingTop: 5,
  },
  container2Popup: {
    backgroundColor: Colors.LightSteelGreen,
    minHeight: "20%",
    width: "95%",
    borderRadius: 20,
    paddingBottom: 40,
    height: "55%",
    paddingTop: 40,
  },
  crossIcon: { width: 25, height: 25, resizeMode: "contain" },
});
