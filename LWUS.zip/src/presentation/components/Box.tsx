import React from 'react';
import {Image, Pressable, StyleSheet, Text, View} from 'react-native';
import Colors from '../../app/utils/Colors';
import {StyledText} from './StyledText';
import Fonts from '../../app/utils/Fonts';
import {HEIGHT, WIDTH} from '../../app/utils/AppConstants';

type Props = {
  year: string;
  icon: any;
  onPress?: () => void;
};

const Box: React.FC<Props> = ({year, icon, onPress}) => {
  return (
    <Pressable style={styles.main} onPress={onPress}>
      <View style={styles.view}>
        <View
          style={{
            flexDirection: 'row',

            alignItems: 'center',
          }}>
          <StyledText text={year} style={styles.item} />
          <Image source={icon} style={styles.icon} />
        </View>
      </View>
    </Pressable>
  );
};

export default Box;
const wid = 175;
const styles = StyleSheet.create({
  type: {color: Colors.black, fontFamily: Fonts.Medium, fontSize: 20},
  icon: {width: 33, height: 33, marginBottom: 9},
  view: {
    flex: 1,
    justifyContent: 'center',
  },
  item: {
    color: Colors.black,
    fontFamily: Fonts.Bold,
    fontSize: 45,
    marginRight: 40,
  },
  linearGradient: {
    flex: 1,
    shadowColor: '#000',
    borderRadius: 15,
    width: wid - 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  // main:{width:wid,height:185,backgroundColor:Colors.white,borderRadius:18,alignItems:'center',padding:6,shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,paddingVertical:8,marginBottom:15},
  main: {
    width: WIDTH * 0.6,
    height: HEIGHT / 6.7,
    backgroundColor: Colors.lightGreen1,
    borderRadius: 18,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 10,

    marginVertical: 28,
  },
});
