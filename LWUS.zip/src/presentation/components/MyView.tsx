import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  SafeAreaView,
  StatusBar,
  Platform,
  ViewStyle,
  ScrollView,
  Pressable,
  Keyboard,
} from 'react-native';
import Colors from '../../app/utils/Colors';
import StyledButton from './StyledButton';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

type Props = {
  navigation?: any;
  style?: ViewStyle;
  children?: any;
  statusBarColor?: string;
  barStyle?: 'dark-content' | 'light-content';
};
type Props2 = {
  backgroundColor: string;
  barStyle?: 'dark-content' | 'light-content';
};
const STATUSBAR_HEIGHT = StatusBar.currentHeight;
export const MyStatusBar = ({backgroundColor, ...props}: Props2) => (
  <View style={[styles.statusBar, {backgroundColor}]}>
    <SafeAreaView>
      <StatusBar translucent backgroundColor={backgroundColor} {...props} />
    </SafeAreaView>
  </View>
);
const MyView: React.FC<Props> = ({
  style,
  children,
  statusBarColor,
  barStyle,
}) => {
  return Platform.OS === 'ios' ? (
    <>
      <MyStatusBar
        barStyle={barStyle ? barStyle : 'dark-content'}
        backgroundColor={statusBarColor ? statusBarColor : Colors.bgColor}
      />
      <SafeAreaView style={[styles.mainContainer, style]}>
        <Pressable onPress={() => Keyboard.dismiss()} style={{flex: 1}}>
          {/* <KeyboardAwareScrollView
          contentContainerStyle={styles.mainContainer}
          contentInsetAdjustmentBehavior='automatic'
        > */}
          {children}
          {/* </KeyboardAwareScrollView> */}
        </Pressable>
      </SafeAreaView>
    </>
  ) : (
    <>
      <StatusBar
        barStyle={barStyle ? barStyle : ('dark-content' as any)}
        backgroundColor={statusBarColor ? statusBarColor : Colors.bgColor}
      />
      <View style={[styles.mainContainer, style]}>
        {/* <KeyboardAwareScrollView
          contentInsetAdjustmentBehavior='automatic'
          contentContainerStyle={styles.mainContainer}
        > */}
        {children}
        {/* </KeyboardAwareScrollView> */}
      </View>
    </>
  );
};

export default MyView;

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: Colors.bgColor,
  },
  mainContainer: {
    flex: 1,
    backgroundColor: Colors.bgColor,
  },
  statusBar: {
    height: STATUSBAR_HEIGHT,
  },
});
