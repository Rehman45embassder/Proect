import React, { useState, useCallback, CSSProperties } from "react";
import {
  View,
  TouchableOpacity,
  Image,
  StyleSheet,
  ViewStyle,
  useColorScheme,
} from "react-native";

import Colors from "../../app/utils/Colors";
import Images from "../../app/utils/Images";
import { StyledText } from "./StyledText";
import Fonts from "../../app/utils/Fonts";
// import DropDownPicker from "react-native-dropdown-picker";
import { HEIGHT, WIDTH } from "../../app/utils/AppConstants";
// import { SelectList } from "react-native-dropdown-select-list";
import { Dropdown } from "react-native-element-dropdown";
import { color } from "@rneui/base";

type Props = {
  value?: any;
  setValue?: any;
  items?: any;
  setItems?: any;
  containerStyle?: CSSProperties | ViewStyle;
  mainContainerStyle?: CSSProperties | ViewStyle;
  setOpen?: any;
  open?: any;
  containerColor?: string;

  headerText?: string;
  textStyle?: any;
  inputTextStyle?: ViewStyle | CSSProperties | any;

  onPress?: any;

  onChange?: any;
};

const StyledDropDown: React.FC<Props> = React.forwardRef((props, ref) => {
  const colorScheme = useColorScheme();

  const renderItem = (item) => {
    return (
      <View>
        <StyledText
          style={{
            color: Colors.Seventy,
            left: WIDTH / 20,
            fontFamily: Fonts.Medium,
            fontSize: Fonts.medium_font,
          }}
          text={item.label}
        />
      </View>
    );
  };

  // Determine if the theme is dark or light
  const isDarkTheme = colorScheme === "dark";
  return (
    <View>
      {props?.headerText && (
        <StyledText
          text={props?.headerText}
          extraStyle={{
            fontSize: 14,
            fontWeight: "normal",
            ...props?.textStyle,
          }}
        />
      )}
      <View>
        <Dropdown
          style={props.containerStyle}
          maxHeight={300}
          labelField="label"
          valueField="value"
          value={props.value}
          onChange={(item) => {
            props.setValue(item.value);
          }}
          renderItem={renderItem}
          //

          //dropdownStyles={{ backgroundColor: "transparent" }}
          //open={props.open}

          data={props.items}
          // scrollViewProps={{
          //   nestedScrollEnabled: true,
          // }}
          // containerStyle={{ height: 250 }}
          // setOpen={props.setOpen}
          // setValue={props.setValue}
          // setItems={props.setItems}
          // // modalContentContainerStyle={{ height: 250 }}
          // dropDownStyle={{ height: HEIGHT, flex: 1 }}
          // style={{
          //   backgroundColor: !props.open ? props.containerColor : "#fff",
          //   borderColor: "transparent",
          // }}
          itemContainerStyle={{ backgroundColor: "#fff" }}
          placeholder="Choose Language"
          placeholderStyle={{
            color: Colors.Seventy,
            left: WIDTH / 20,
            fontFamily: Fonts.Regular,
            fontSize: Fonts.medium_font,
          }}
          itemTextStyle={{
            fontFamily: Fonts.Medium,
            fontSize: Fonts.medium_font,
            color: Colors.Seventy,
          }}
          selectedTextStyle={{
            fontFamily: Fonts.Medium,
            fontSize: Fonts.medium_font,
            color: Colors.Seventy,
            left: WIDTH / 20,
          }}
        />
      </View>
    </View>
  );
});

export default StyledDropDown;

const styles = StyleSheet.create({
  mainContainer: {
    height: 60,

    paddingHorizontal: 15,

    paddingBottom: 0,
    marginHorizontal: -10,
  },
});
