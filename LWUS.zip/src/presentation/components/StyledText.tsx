import React, { CSSProperties } from "react";
import { Text, TouchableOpacity, ViewStyle, TextStyle } from "react-native";
import Colors from "../../app/utils/Colors";
import Fonts from "../../app/utils/Fonts";

type Props = {
  text?: string;
  style?: ViewStyle | CSSProperties;
  noOfLines?: number;
  onPress?: () => void;
  extraStyle?: ViewStyle | CSSProperties;
};

export const StyledText: React.FC<Props> = (props) => {
  return (
    <TouchableOpacity
      onPress={props?.onPress}
      disabled={props?.onPress ? false : true}
    >
      <Text
        numberOfLines={props?.noOfLines}
        style={
          [
            {
              fontFamily: Fonts.Regular,
              color: Colors.white,
              fontSize: 14,
              ...props?.style,
            },
            props.extraStyle,
          ] as TextStyle
        }
      >
        {props?.text ? props?.text : "loading..."}
      </Text>
    </TouchableOpacity>
  );
};
