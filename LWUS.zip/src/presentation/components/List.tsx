import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import Colors from "../../app/utils/Colors";
import { StyledText } from "./StyledText";
import LinearGradient from "react-native-linear-gradient";
import Fonts from "../../app/utils/Fonts";
import { HEIGHT, WIDTH } from "../../app/utils/AppConstants";

type Props = {
  fieldName: string;
  item: string;
  bu: string;
  cropYield: string;

  onPress?: () => void;
};

const List: React.FC<Props> = ({
  fieldName,
  item,
  bu,
  cropYield,

  onPress,
}) => {
  return (
    <Pressable style={styles.main} onPress={onPress}>
      <View style={styles.view}>
        <StyledText text={fieldName} style={styles.type} />
        <StyledText text={item} style={styles.item} />
        <View>
          <StyledText text={`${bu} bu.`} style={styles.days} />
          <StyledText text={`${cropYield} yield.`} style={styles.days} />
        </View>
      </View>
    </Pressable>
  );
};

export default List;
const wid = 175;
const styles = StyleSheet.create({
  type: { color: Colors.black, fontFamily: Fonts.Medium, fontSize: 17 },
  days: { color: Colors.black, fontFamily: Fonts.Regular, fontSize: 14 },
  view: {
    width: WIDTH / 1.1,
    flexDirection: "row",
    flex: 1,
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 12,
  },
  item: { color: Colors.black, fontFamily: Fonts.Regular, fontSize: 16 },

  // main:{width:wid,height:185,backgroundColor:Colors.white,borderRadius:18,alignItems:'center',padding:6,shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,paddingVertical:8,marginBottom:15},
  main: {
    flex: 1,
    width: WIDTH / 1.1,
    height: HEIGHT / 9,
    backgroundColor: Colors.LightSteelGreen,

    borderRadius: 15,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 5,
    paddingVertical: 4,
    marginBottom: 10,
  },
});
