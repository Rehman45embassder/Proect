import React, { CSSProperties, useState } from "react";
import {
  Animated,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ViewStyle,
} from "react-native";
import MyView from "../components/MyView";
import Colors from "../../app/utils/Colors";
import Images from "../../app/utils/Images";
import { StyledText } from "./StyledText";
import Fonts from "../../app/utils/Fonts";
import { useDrawerStatus } from "@react-navigation/drawer";
import { toast } from "../../app/utils/ErrorHandler";
import { navigate, navigateClear } from "../navigation/NavigationService";
import Dialogs from "./Dialogs";
import { closeDrawer } from "../navigation/Navigations";
import LinearGradient from "react-native-linear-gradient";
// import ShareDialogs from "./ShareDialogs";
// import { color } from "@rneui/base";
import { HEIGHT, WIDTH } from "../../app/utils/AppConstants";
import { useDispatch, useSelector } from "react-redux";
import { logOut } from "../modules/dashboard/drawer/profile/EditProfileViewModel";

type Props = {
  state?: {
    routes?: any;
  };
};

const margin = 12;
const MyDrawer: React.FC<Props> = ({ state }) => {
  const [modal, setModal] = React.useState(false);
  const [modal2, setModal2] = React.useState(false);
  const [loader, setLoader] = React.useState(false);
  const isDrawerOpen = useDrawerStatus() === "open";
  const profileData = useSelector((state: any) => state?.UseData?.profileInfo);
  // const [profileName, setProfileName] = React.useState(profileData?.full_name);
  const [profileImage, setProfileImage] = React.useState(null);
  const animateRight = React.useRef(new Animated.Value(220)).current;
  const opacity = React.useRef(new Animated.Value(0)).current;
  const dispatch = useDispatch();
  console.log("reducer data in drawer");
  React.useEffect(() => {
    Animated.timing(animateRight, {
      toValue: 0,
      duration: 600,
      useNativeDriver: false,
      delay: 300,
    }).start();
    Animated.timing(opacity, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: false,
      delay: 300,
    }).start();
  }, [isDrawerOpen]);
  React.useEffect(() => {
    if (!isDrawerOpen) {
      animateRight.setValue(220);
      opacity.setValue(0);
    }
  }, [isDrawerOpen]);
  return (
    <MyView style={styles.mainContainer} barStyle="light-content">
      <LinearGradient
        colors={["#096728", "#43A02B"]} // replace with your desired colors
        style={styles.gradient}
      />

      {/* <Animated.View style={{right:animateRight,opacity:opacity}}> */}
      <Animated.View>
        <Pressable
          onPress={() => closeDrawer()}
          style={{
            marginTop: HEIGHT / 25,
            paddingRight: WIDTH / 16,
            justifyContent: "flex-end",

            alignItems: "flex-end",
          }}
        >
          <StyledText
            text="X"
            extraStyle={{
              color: Colors.white,
              fontFamily: Fonts.SemiBold,
              fontSize: 22,
            }}
          />
        </Pressable>
        <Pressable
          style={styles.topView}
          onPress={() => navigate("My Profile")}
        >
          <Image
            source={
              profileData?.pictureLink === null
                ? Images.IcContact
                : {
                    uri:`http://13.232.41.211/culturelingo/api/v1/files?fileName=${profileData?.pictureLink}`
                  }
            }
            style={styles.image}
          />
          <StyledText text={profileData?.name} style={styles.name} />
        </Pressable>
      </Animated.View>
      <View style={{ marginVertical: 15 }}>
        {state?.routes.map(
          (item: { name: string; params?: { Images?: any } }, index: any) => (
            // <Animated.View style={{right:animateRight}}>
            <Animated.View>
              <TouchableOpacity
                style={[
                  styles.topView2,
                  { marginTop: item.name === "Logout" ? 50 : margin },
                ]}
                onPress={() => {
                  if (item?.name === "Logout") {
                    setModal(!modal);
                  }
                  if (item?.name === "Share App") {
                    setModal2(!modal2);
                  } else navigate(item?.name);
                }}
              >
                <Image source={item?.params?.Images} style={styles.icon} />
                <StyledText text={item.name} style={styles.text} />
              </TouchableOpacity>
            </Animated.View>
          )
        )}
      </View>
      {/* <ShareDialogs
        checkIcon
        Icon={Images.IcDeleteAccount}
        visible={modal2}
        onClose={() => setModal2(!modal2)}
        popup
      /> */}

      <Dialogs
        visible={modal}
        onClose={() => setModal(!modal)}
        onBtn1Press={() => {
          setModal(!modal);
        }}
        onBtn2Press={() => {
          logOut({
            navigation: navigateClear,
            setLoader: setLoader,
            setModal: setModal,
            dispatch: dispatch,
          });
          // setModal(!modal);
          // navigate("SignIn");
          closeDrawer();
        }}
        popup
        checkIcon
        Icon={Images.IcLogOut2}
        title="LOG OUT"
        btn1="No"
        btn2="Yes"
        description={"Are you sure, you want to logout?"}
      />
    </MyView>
  );
};

export default MyDrawer;

const styles = StyleSheet.create({
  topView: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 0,
    paddingVertical: 15,
    borderBottomColor: Colors.white,
    borderBottomWidth: 0.3,
  },
  topView2: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 25,
    marginVertical: margin,
  },
  name: {
    fontFamily: Fonts.Medium,
    fontSize: Fonts.xlarge_font,
    marginLeft: 13,
  },
  image: { width: 65, height: 65, resizeMode: "contain", borderRadius: 35 },
  text: {
    fontSize: Fonts.large_font - 1,
    marginLeft: 15,
    fontFamily: Fonts.Regular,
  },
  mainContainer: {
    width: 280,
    backgroundColor: "#43A02B",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.27,
    shadowRadius: 4.65,
    elevation: 6,
  },
  gradient: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  icon: { width: 23, height: 23, resizeMode: "contain", marginHorizontal: 3 },
});
