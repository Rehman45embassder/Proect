import {
  CommonActions,
  DrawerActions,
  createNavigationContainerRef,
} from '@react-navigation/native';
import {toast} from '../../app/utils/ErrorHandler';
export const navigationRef = createNavigationContainerRef();

export const navigate = (name: string, params?: any) => {
  if (navigationRef.isReady()) {
    navigationRef.navigate(name, params);
  } else {
    toast('Something went wrong.');
  }
};
export const navigateClear = (name: string, params?: any) => {
  if (navigationRef.isReady()) {
    navigationRef?.current?.dispatch(
      CommonActions.reset({
        index: 0,
        routes: [{name: name}],
      }),
    );
  } else {
    toast('Something went wrong.');
  }
};
//latest
export const goBack = () => {
  if (navigationRef.isReady()) {
    navigationRef.goBack();
  }
};
