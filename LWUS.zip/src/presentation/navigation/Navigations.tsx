import React, { useEffect } from "react";
import { DrawerActions, NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import SplashScreen from "../modules/common/SplashScreen";
import SignInScreen from "../modules/authentication/signin/SignInScreen";
import { goBack, navigationRef } from "./NavigationService";
import SignUpScreen from "../modules/authentication/signup/SignUpScreen";
import ForgotPasswordScreen from "../modules/authentication/forgot_password/ForgotPasswordScreen";
import OTPVerify from "../modules/authentication/OTPVerify/OTPVerify";
import ResetPasswordScreen from "../modules/authentication/reset_password/ResetPasswordScreen";
// import OnBoarding from "../modules/authentication/onBoarding/OnBoarding";
// import Subscription from "../modules/dashboard/subscription/Subscription";
// import AddCard from "../modules/dashboard/subscription/add_card/AddCard";
import TitleBar from "../components/TitleBar";
// import Dashboard from "../modules/dashboard/Dashboard";
import { Alert, Image, StatusBar } from "react-native";
import Images from "../../app/utils/Images";
import MyDrawer from "../components/MyDrawer";
import { createDrawerNavigator } from "@react-navigation/drawer";
// import History from "../modules/dashboard/drawer/history/History";
// import Settings from "../modules/dashboard/drawer/settings/Settings";
// import AddNewCrop from "../modules/dashboard/addCrop/AddNewCrop";
// import AddField from "../modules/dashboard/addNewField/AddField";
// import ShowField from "../modules/dashboard/addNewField/ShowField";
// import Filter from "../modules/dashboard/filter/Filter";
// import ShowLoads from "../modules/dashboard/showLoads/ShowLoads";
// import ShowHistory from "../modules/dashboard/drawer/history/ShowHistory";
// import CropDetails from "../modules/dashboard/cropDetails/CropDetails";
// import ScanQR from "../modules/dashboard/scanQR/ScanQR";
// import ScanCount from "../modules/dashboard/drawer/scanCount/ScanCount";
// import Profile from "../modules/dashboard/drawer/profile/Profile";
// import EditProfile from "../modules/dashboard/drawer/profile/EditProfile";
// import ContactAdmin from "../modules/dashboard/drawer/contactAdmin/ContactAdmin";
// import PaymentMethod from "../modules/dashboard/drawer/settings/payment_method/PaymentMethod";
// import Payment from "../modules/dashboard/drawer/settings/payment_method/payment/Payment";
// import ManageSubscription from "../modules/dashboard/drawer/settings/manageSubscription/ManageSubscription";
// import ChangePassword from "../modules/dashboard/drawer/settings/change_password/ChangePassword";
// import DeleteAccount from "../modules/dashboard/drawer/settings/delete_account/DeleteAccount";
// import PrivacyPolicy from "../modules/dashboard/drawer/settings/privacy_policy/PrivacyPolicy";
// import Terms from "../modules/dashboard/drawer/settings/terms_condition/Terms";
// import messaging from "@react-native-firebase/messaging";
import { useDispatch } from "react-redux";
import { fcmToken } from "../../app/redux/slice";
import Profile from "../modules/dashboard/drawer/profile/Profile";
import Dashboard from "../modules/dashboard";
import EditProfile from "../modules/dashboard/drawer/profile/EditProfile";
import DailyPhrase from "../modules/dashboard/DailyPhrases/DailyPhrase";
import TranslationScreen from "../modules/dashboard/TranslationScreen/TranslationsScreen";
import History from "../modules/dashboard/History/History";
import Quiz from "../modules/dashboard/Quiz/Quiz";
//import Notification from "../modules/dashboard/notification/Notification";

function Navigations() {
  const Stack = createNativeStackNavigator();
  const dispatch = useDispatch();
 
  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen
          options={{ headerShown: false }}
          name="Splash"
          component={SplashScreen}
        />
        <Stack.Screen name="SignIn" component={SignInScreen} />
        <Stack.Screen name="SignUp" component={SignUpScreen} />
        <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
        <Stack.Screen name="OtpVerify" component={OTPVerify} />
        <Stack.Screen name="EditProfile" component={EditProfile} />
        <Stack.Screen name="ResetPassword" component={ResetPasswordScreen} />
        <Stack.Screen name="Daily" component={DailyPhrase} />
        <Stack.Screen name="Translation" component={TranslationScreen} />
        <Stack.Screen name="History" component={History} />
        <Stack.Screen name="Quiz" component={Quiz} />
        
        <Stack.Screen name="Home" component={Drawer} />
        
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export const openDrawer = () =>
  navigationRef.dispatch(DrawerActions.openDrawer());
export const closeDrawer = () =>
  navigationRef.dispatch(DrawerActions.closeDrawer());
const Drawer = () => {
  const Drawer = createDrawerNavigator();
  return (
    <Drawer.Navigator
      initialRouteName="Home Screen"
      screenOptions={{ headerShown: false }}
      drawerContent={(props) => <MyDrawer {...props} />}
    >

<Drawer.Screen
        name="Home Screen"
        initialParams={{ Images: Images.IcDashboard }}
        component={Dashboard}
      />
 <Drawer.Screen
         name="My Profile"
         initialParams={{ Images: Images.IcWhiteUser }}
         component={Profile}
     />
     
      {/* <Drawer.Screen
        name="History"
        initialParams={{ Images: Images.IcHistory }}
        component={History}
      />

      <Drawer.Screen
        name="Scan Count"
        initialParams={{ Images: Images.IcScan }}
        component={ScanCount}
      />

      // <Drawer.Screen
      //   name="My Profile"
      //   initialParams={{ Images: Images.IcWhiteUser }}
      //   component={Profile}
     />
      <Drawer.Screen
        name="Settings"
        initialParams={{ Images: Images.IcSettings }}
        component={Settings}
      />

      <Drawer.Screen
        name="Contact Admin"
        initialParams={{ Images: Images.IcHeadphones }}
        component={ContactAdmin}
      /> */}
{/* 
      <Drawer.Screen
        name="Tutorial"
        initialParams={{ Images: Images.IcVideo }}
        component={OnBoarding}
      />

      <Drawer.Screen
        name="Share App"
        initialParams={{ Images: Images.IcShare }}
        component={History}
      /> */}
      <Drawer.Screen
        name="Logout"
        initialParams={{ Images: Images.IcLogOut }}
        component={Dashboard}
      />
    </Drawer.Navigator>
  );
};

export default Navigations;
