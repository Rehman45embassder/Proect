import axios from "axios";
import { SignUpRequest } from "../model/request/SignUpRequest";
import { BaseResponse } from "../model/response/BaseResponse";
import { BASEURL } from "../../app/utils/AppConstants";
import { LoginRequest } from "../model/request/LoginRequest";
import { UpdateProfile } from "../../presentation/modules/dashboard/drawer/profile/type";

axios.defaults.baseURL = BASEURL;
axios.defaults.headers.common["accept"] = "application/json";
// axios.defaults.headers.common['Content-Type'] = 'application/json';
export const post = (url: string, params = {}, headers?: any) =>
  axios.post<BaseResponse<string>>(url, params, { headers });
export const get = (url: string, params = {}) =>
  axios.get<BaseResponse<string>>(url, { params });
const put = (url: string, params = {}) => axios.put(url, params);
const destroy = (url: string, data = {}, headers?: any) =>
  axios.delete(url, { headers, data });

const setAuthHeader = (token: string) => {
  axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
};

const clearTokenOnLogout = () => {
  // Delete the Authorization header from the defaults
  delete axios.defaults.headers.common['Authorization'];
};

export default {
  setAuthHeader,clearTokenOnLogout,
  auth: {
    login: (params: any) =>
      axios.post<BaseResponse<string>>("auth/login", params),
    signUp: (params: any,header: any) =>
      axios.post<BaseResponse<string>>("users", params,header),
  },
  lang: {
    getAllLanguages: () =>
      axios.get<BaseResponse<string>>("languages"),
    
  },

  addData: {
   
    forgetPassword: (params: any) => post("forgot-password", params),
    resetPassword: (params: any) => post("reset-password", params),
    changePassword: (params: any) => post("profile/password/update", params),
    addCard: (params: any) => post("card/add", params),
    addCropField: (params: any) => post("crop/add/field", params),
    passVerify: (params: any) => post("change-password-verify", params),
    showAllField: (params: any) => post("crop/add/crop-year", params),
    showYearlyField: (params: any) => post("crop/history-data", params),
    filter: (params: any) => post("crop/filter-history", params),
    addManuallyLoad: (params: any) =>
      post(`crop/${params.id}/addload-manually`, params),
    showAllLoads: (params: any) => post("crop/filter-history-loads", params),
    cancelSubscription: (params: any) =>
      post("stripe/cancel/subscription", params),
    upgradeField: (params: any) => post("crop/update", params),
    updateCard: (params: any) => post("stripe/update/card", params),
    logout: () => post("logout"),
    deleteAccount: () => post("deleteAccount"),
    contactAdmin: (params: any) => post("contactAdmin", params),
    notificationList: (params: any) =>
      post("profile/notification/list", params),
    notificationCount: () => post("profile/notification/count"),
    notificationMarkRead: (params: any) =>
      post("profile/notification/read", params),
  },
  OTP: {
    accountVerify: (params: any,header:any) =>{ console.log('====================================');
    console.log(params);
    console.log('===================================='); get(`users/verify?token=${params}`,)},
    forgetPasswordOTP: (params: any) => post("reset-password-otp", params),
    verifyOTP: (params: any) => post("verify-otp", params),
  },
  userData: {
    profileData: () => axios.get<BaseResponse<string>>("users/profile"),
    profileUpdate: (url:any,params: any,header:any) => {
      console.log('====================================');
      console.log("params",params,"id", url,"header",header);
      console.log('====================================');
      return axios.
    put(url, params,header)}
  },
  scanCount: () => axios.get<BaseResponse<string>>("crop/scan-count"),
  homeScreenYear: () => axios.get<BaseResponse<string>>("crop/homeScreen"),
  historyScreenYear: () =>
    axios.get<BaseResponse<string>>("crop/history-years"),
  showCropDetails: (params: any) =>
    axios.get<BaseResponse<string>>(`crop/${params.id}/show`),
  cardDetails: () => axios.get<BaseResponse<string>>("stripe/cardDetails"),
  tutorialStep1: () => axios.get<BaseResponse<string>>("tutorial/stepone"),
  tutorialStep2: () => axios.get<BaseResponse<string>>("tutorial/steptwo"),
  tutorialStep3: () => axios.get<BaseResponse<string>>("tutorial/stepthree"),
};
