export interface ErrorResponse{
    statusCode: number;
    message: string;
}