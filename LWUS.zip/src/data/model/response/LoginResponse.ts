export interface LoginResponse{
  data: string
}