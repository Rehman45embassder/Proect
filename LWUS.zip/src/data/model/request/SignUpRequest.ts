export interface SignUpRequest {
  first_name: string;
  last_name: string;
  email: string;
  city: string;
  state: string;
  password: string;
  password_confirmation: string;
  phone: string;
  term_conditions: boolean;
  navigation?: any;
}
